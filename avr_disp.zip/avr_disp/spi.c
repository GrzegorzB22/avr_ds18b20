#include "used_pins.h"
#include <avr/io.h>


void SPI_Init(void)
{
	DDR_SET(SPI_MOSI_PIN);
	DDR_SET(SPI_SCK_PIN);
	DDR_SET(SPI_CS_PIN);

	DDR_RST(SPI_MISO_PIN);
	SPCR = _BV(SPE) | _BV(MSTR);
}

void SPI_Transmit(uint8_t data)
{
	SPDR = data;

	while ( !(SPSR & _BV(SPIF)));
}

uint8_t SPI_Receive(void)
{
	while ( !(SPSR & _BV(SPIF)));

	return SPDR;
}

uint8_t SPI_TR(uint8_t data)
{
	SPDR = data;

	while ( !(SPSR & _BV(SPIF)));

	return SPDR;
}
