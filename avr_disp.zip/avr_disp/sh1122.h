/*
 * disp.h
 *
 *  Created on: 9 wrz 2024
 *      Author: re-gb
 */

// SH1122

#ifndef SH1122_H_
#define SH1122_H_

#include "used_pins.h"

#define SH_DATA_TYPE	PORT_SET(SH_DC_PIN)
#define SH_COMM_TYPE	PORT_RST(SH_DC_PIN)


#define SH_WIDTH  256
#define SH_HEIGHT 64


void SH_setColumnAdr(int column);
void SH_setDispStartLine(int line);
void SH_setContrast(int contrast);
//void SH_setSegRemap(int remap);
void SH_setEntireDisp(int state);
void SH_setDispReverse(int mode);
void SH_setMultiplexRatMode(int ratmode);
//void SH_setDCMode(int dcmode);
void SH_displayPower(int power);
void SH_displayOffset(int offset);
void SH_transmitData(int data);


void Display_Init(void);


#endif /* SH1122_H_ */
