#include "used_pins.h"
#include "sh1122.h"
#include "spi.h"

#define COMM 0
#define DATA 1

static int sh_buffer[SH_WIDTH * SH_HEIGHT];

static void SH_transmit1byte(int byte, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(byte);
	SPI_STOP;
}

static void SH_transmit2bytes(int bytes, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(bytes >> 8);
	SPI_Transmit(bytes & 0x00FF);
	SPI_STOP;
}

void SH_setColumnAdr(int column)
{

}

void SH_setDispStartLine(int line);
void SH_setContrast(int contrast);
void SH_setEntireDisp(int state);
void SH_setDispReverse(int mode);
void SH_setMultiplexRatMode(int ratmode);
void SH_displayPower(int power);
void SH_displayOffset(int offset);
void SH_transmitData(int data);
