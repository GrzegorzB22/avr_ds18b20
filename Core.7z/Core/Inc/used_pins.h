

#ifndef INC_USED_PINS_H_
#define INC_USED_PINS_H_

#include "main.h"

#define SH_DC_PORT  GPIOB
#define SH_DC_PIN   GPIO_PIN_13

#define SH_RST_PORT GPIOB
#define SH_RST_PIN  GPIO_PIN_14

#define SPI_CS_PORT GPIOB
#define SPI_CS_PIN  GPIO_PIN_15

#define ENC_A_PORT  GPIOC
#define ENC_A_PIN   GPIO_PIN_8

#define ENC_B_PORT  GPIOC
#define ENC_B_PIN   GPIO_PIN_6

#define ENC_BUT_PORT GPIOC
#define ENC_BUT_PIN  GPIO_PIN_5

#endif /* INC_USED_PINS_H_ */
