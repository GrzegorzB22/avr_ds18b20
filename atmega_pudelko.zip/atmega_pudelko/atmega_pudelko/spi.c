
#include <avr/io.h>
#include "spi.h"
#include "used_pins.h"

void SPI_init(void)
{
	SPI_SET_DDR(SPI_MOSI_PIN);
	SPI_SET_DDR(SPI_CS_PIN);
	SPI_SET_DDR(SPI_SCK_PIN);
	SPI_CLR_DDR(SPI_MISO_PIN);
	
	SPI_SET_PORT(SPI_MISO_PIN);
	
	SPCR |= _BV(SPE) | _BV(MSTR);   // wlaczenie spi i ustawienie avr jako master
	SPCR |= _BV(SPR0);  // to i na dole ustawienie 1 Mhz clock spi
	SPSR |= _BV(SPI2X);
}

void SPI_transmit(uint8_t data)
{
	SPDR = data;
	while (!(SPSR & _BV(SPIF)));
}

uint8_t SPI_receive(void)
{
	while (!(SPSR & _BV(SPIF)));
	
	return SPDR;
}