
#include <avr/io.h>
#include "pin_defines.h"
#include "spi.h"


void SPI_init(void)
{
	SPI_MOSI.DIR |= SPI_MOSI_PIN;
	SPI_SCK.DIR  |= SPI_SCK_PIN;
	SPI_CS.DIR   |= SPI_CS_PIN;
	SPI_MISO.DIR &= ~SPI_MISO_PIN;
	
	SPI0.CTRLA |= SPI_MASTER_bm;     // ustawienie avr jako master
	SPI0.CTRLA |= SPI_PRESC_DIV4_gc; // ustawienie zegara spi fosc/4 
	SPI0.CTRLA |= SPI_ENABLE_bm;     // wlaczenie spi
}

void SPI_transmit(uint8_t data)
{
	SPI0.DATA = data;
	while ((SPI0.INTFLAGS & SPI_IF_bm) == 0)
		;
}