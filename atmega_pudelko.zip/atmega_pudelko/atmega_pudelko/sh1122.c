
#include "sh1122.h"
#include "pin_defines.h"
#include <avr/io.h>
#include <util/delay.h>

static uint8_t sh_buffer[SH_WIDTH * SH_HEIGHT / 2];


static void SH_cmdb(uint8_t cmd)
{
	SH_CMD_PROCESS;
	SPI_transmit(cmd);
	_delay_us(100);
}

static void SH_cmdbb(uint8_t cmd_h, uint8_t cmd_l)
{
	SH_CMD_PROCESS;
	SPI_transmit(cmd_h);
	_delay_us(100);
	SPI_transmit(cmd_l);
	_delay_us(100);
}

static void SH_rst(void)
{
	SH_RST.OUT &= ~SH_RST_PIN;
	_delay_us(200);
	SH_RST.OUT |= SH_RST_PIN;
	_delay_ms(200);
}

void SH_init(void)
{
	SH_DC.DIR  |= SH_DC_PIN;
	SH_RST.DIR |= SH_RST_PIN;
	
	SH_rst();
}

void SH_setColumn(uint8_t column)
{
	column &= 0x7F;
	uint8_t col_h = (column >> 4) | 0x10;
	uint8_t col_l = column & 0x0F;

	SPI_START;
	SH_cmdbb(col_h, col_l);
	SPI_STOP;
}

void SH_setDispLine(uint8_t line)
{
	line &= 0x3F;

	SPI_START;
	SH_cmdb(line);
	SPI_STOP;
}

void SH_setContrast(uint8_t contrast)
{
	uint8_t contrast_msb = 0x81;

	SPI_START;
	SH_cmdbb(contrast_msb, contrast);
	SPI_STOP;
}

void SH_setRemap(uint8_t remap)
{
	remap &= 0x01;

	SPI_START;
	SH_cmdb(remap | 0xA0);
	SPI_STOP;
}

void SH_setEntireDisp(uint8_t state)
{
	state &= 0x01;

	SPI_START;
	SH_cmdb(state | 0xA4);
	SPI_STOP;
}

void SH_setDispMode(uint8_t mode)
{
	mode &= 0x01;

	SPI_START;
	SH_cmdb(mode | 0xA6);
	SPI_STOP;
}

void SH_setDispPower(uint8_t power)
{
	power &= 0x01;

	SPI_START;
	SH_cmdb(power | 0xAE);
	SPI_STOP;
}

void SH_setOffset(uint8_t offset)
{
	uint8_t offset_msb = 0xD3;
	offset &= 0x3F;

	SPI_START;
	SH_cmdbb(offset_msb, offset);
	SPI_STOP;
}

void SH_setRowAdr(uint8_t row)
{
	uint8_t row_msb = 0xB0;
	row &= 0x3F;

	SPI_START;
	SH_cmdbb(row_msb, row);
	SPI_STOP;
}