/*
 * spi.h
 *
 * Created: 10.10.2024 21:12:26
 *  Author: Admin
 */ 


#ifndef SPI_H_
#define SPI_H_

#include <avr/io.h>

void SPI_init(void);
void SPI_transmit(uint8_t data);
uint8_t SPI_receive(void);

#endif /* SPI_H_ */