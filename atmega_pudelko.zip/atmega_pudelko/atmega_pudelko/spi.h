/*
 * spi.h
 *
 * Created: 28.10.2024 15:37:26
 *  Author: re-gb
 */ 


#ifndef SPI_H_
#define SPI_H_

#include <avr/io.h>
#include "pin_defines.h"

#define SPI_START SPI_CS.OUT &= ~_BV(SPI_CS_PIN)
#define SPI_STOP  SPI_CS.OUT |= _BV(SPI_CS_PIN)

void SPI_transmit(uint8_t data);
void SPI_init(void);



#endif /* SPI_H_ */