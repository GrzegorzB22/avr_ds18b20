/*
 * pin_defines.h
 *
 * Created: 28.10.2024 15:38:42
 *  Author: re-gb
 */ 


#ifndef PIN_DEFINES_H_
#define PIN_DEFINES_H_

#define SPI_CS        PORTA
#define SPI_CS_PIN    PIN7_bm

#define SPI_MOSI      PORTA
#define SPI_MOSI_PIN  PIN4_bm

#define SPI_MISO      PORTA
#define SPI_MISO_PIN  PIN5_bm

#define SPI_SCK       PORTA
#define SPI_SCK_PIN   PIN6_bm

#define SH_RST        PORTA
#define SH_RST_PIN    PIN3_bm

#define SH_DC         PORTA
#define SH_DC_PIN     PIN2_bm

#endif /* PIN_DEFINES_H_ */