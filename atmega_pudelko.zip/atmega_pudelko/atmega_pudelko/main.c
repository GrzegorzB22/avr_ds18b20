/*
 * atmega_pudelko.c
 *
 * Created: 28.10.2024 15:36:25
 * Author : re-gb
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

