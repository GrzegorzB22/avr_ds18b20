/*
 * atmega_pudelko.c
 *
 * Created: 10.10.2024 20:58:40
 * Author : Admin
 */ 

#include <avr/io.h>
#include "spi.h"
#include "used_pins.h"
#include "sh1122.h"


int main(void)
{
    SPI_init();
	SH_init();
	SH_clear();
	
	SH_drawString(0, 0, "ABCD", 15, 1);
	SH_update();
	
    while (1) 
    {
    }
}

