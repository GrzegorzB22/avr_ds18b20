/*
 * sh1106.h
 *
 *  Created on: 11 wrz 2024
 *      Author: re-gb
 */

#ifndef SH1122_H_
#define SH1122_H_

#include <avr/io.h>
#include "used_pins.h"

#define NUM  0
#define CHAR 1
#define NONE 3

#define SH_WIDTH 256
#define SH_HEIGHT 64

#define SH_DATA_PROCESS SH_SET_PORT(SH_DC_PIN)
#define SH_CMD_PROCESS  SH_CLR_PORT(SH_DC_PIN)

#define SPI_START	SPI_CLR_PORT(SPI_CS_PIN)
#define SPI_STOP	SPI_SET_PORT(SPI_CS_PIN)

void SH_setColumn(uint8_t column);
void SH_setDispLine(uint8_t line);
void SH_setContrast(uint8_t contrast);
void SH_setRemap(uint8_t remap);
void SH_setEntireDisp(uint8_t state);
void SH_setDispMode(uint8_t mode);
void SH_setOffset(uint8_t offset);
void SH_setDispPower(uint8_t power);
void SH_putPixel(uint16_t, uint16_t y, uint8_t color);
void SH_drawRectangle(uint16_t x0, uint16_t y0, uint16_t width, uint16_t height, uint8_t color);
void SH_drawHLine(uint16_t x0, uint16_t y,  uint16_t width, uint8_t color);
void SH_drawVLine(uint16_t x,  uint16_t y0, uint16_t height, uint8_t color);
void SH_setRowAdr(uint8_t row);

void SH_init(void);
void SH_update(void);
void SH_clear(void);
void SH_drawChar(uint16_t x, uint16_t y, uint8_t ch, uint8_t color);
void SH_drawString(uint16_t x, uint16_t y, char *s, uint8_t color, uint8_t size);

void SH_displayTime(uint16_t d, uint8_t h, uint8_t m, uint8_t s);
void SH_background(uint8_t color);

void SH_sleep(void);

#endif /* SH1122_H_ */
