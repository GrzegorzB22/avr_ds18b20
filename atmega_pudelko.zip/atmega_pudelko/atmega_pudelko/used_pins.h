/*
 * used_pins.h
 *
 * Created: 10.10.2024 21:10:58
 *  Author: Admin
 */ 


#ifndef USED_PINS_H_
#define USED_PINS_H_

#include <avr/io.h>


#define CONCATENATE(x, y)	(x ## y)
#define SETx(dp, dp_name, dp_pin_number)			(CONCATENATE(dp, dp_name) |= _BV(dp_pin_number))
#define CLRx(dp, dp_name, dp_pin_number)			(CONCATENATE(dp, dp_name) &= ~_BV(dp_pin_number))
#define READx(dp, dp_name, dp_pin_number)			(CONCATENATE(dp, dp_name) & _BV(dp_pin_number))

#define SPI_SET_DDR(x)	SETx(DDR, x)
#define SPI_SET_PORT(x)	SETx(PORT, x)

#define SPI_CLR_DDR(x)	CLRx(DDR, x)
#define SPI_CLR_PORT(x)	CLRx(PORT, x)

#define SH_SET_DDR(x)	SETx(DDR, x)
#define SH_SET_PORT(x)	SETx(PORT, x)

#define SH_CLR_DDR(x)	CLRx(DDR, x)
#define SH_CLR_PORT(x)	CLRx(PORT, x)

#define SPI_CS_PIN   B, 4
#define SPI_MOSI_PIN B, 5
#define SPI_MISO_PIN B, 6
#define SPI_SCK_PIN  B, 7

#define SH_RST_PIN   D, 0
#define SH_DC_PIN    D, 1

#endif /* USED_PINS_H_ */