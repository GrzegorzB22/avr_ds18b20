/*
 * spi.h
 *
 *  Created on: 9 wrz 2024
 *      Author: re-gb
 */

#ifndef SPI_H_
#define SPI_H_

#include "used_pins.h"

#define SPI_START	PORT_RST(SPI_SCK_PIN)
#define SPI_STOP	PORT_SET(SPI_SCK_PIN)



void SPI_Init(void);
void SPI_Transmit(int data);
int SPI_Receive(void);
int SPI_TR(int data);

#endif /* SPI_H_ */
