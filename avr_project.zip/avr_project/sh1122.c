#include "used_pins.h"
#include "sh1122.h"
#include "spi.h"

#define COMM 0
#define DATA 1

static int sh_buffer[SH_WIDTH * SH_HEIGHT];

static void SH_transmit1byte(uint8_t byte, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(byte);
	SPI_STOP;
}

static void SH_transmit2bytes(uint16_t bytes, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(bytes >> 8);
	SPI_Transmit(bytes & 0x00FF);
	SPI_STOP;
}


void SH_setColumnAdr(uint8_t column)
{
	column &= 0x7F;
	uint8_t ch = (column >> 4) | 0x10;
	uint8_t cl = column & 0x0F;
	
	SH_transmit2bytes((ch << 8) | cl);
}

void SH_setDispStartLine(uint8_t line)
{
	line &= 0x3F;
	SH_transmit1byte(line | 0x40);
}


void SH_setContrast(uint8_t contrast)
{
	uint8_t cmd = 0x81;
	SH_transmit2bytes((cmd << 8) | contrast);
}

void SH_setEntireDisp(uint8_t state)
{
	state &= 0x01;
	SH_transmit1byte(0xA4 | state);
}


void SH_setDispReverse(uint8_t mode)
{
	mode &= 0x01;
	SH_transmit1byte(0xA6 | mode);
}


void SH_setMultiplexRatMode(uint8_t ratmode)
{
	ratmode &= 0x3F;
	
	uint8_t mode_set = 0xA8;
	SH_transmit2bytes((mode_set << 8) | ratmode);
}


void SH_displayPower(uint8_t power)
{
	power &= 0x01;
	SH_transmit1byte(0xAE | power);
}

void SH_displayOffset(uint8_t offset)
{
	offset &= 0x3F;
	
	uint8_t mode_set = 0xD3;
	SH_transmit2bytes((mode_set << 8) | offset);
}

void SH_transmitData(uint8_t data)
{
	SH_transmit1byte(data);
}
