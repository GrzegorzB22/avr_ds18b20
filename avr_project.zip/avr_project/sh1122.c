#include "used_pins.h"
#include "sh1122.h"
#include "spi.h"

#define COMM 0
#define DATA 1

#define POWER_ON  1
#define POWER_OFF 0

static uint8_t sh_buffer[(SH_WIDTH / 2) * SH_HEIGHT];
uint8_t grayScale[15];

static void SH_transmit1byte(uint8_t byte, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(byte);
	SPI_STOP;
}

static void SH_transmit2bytes(uint16_t bytes, int dc)
{
	if (dc) SH_DATA_TYPE;
	else    SH_COMM_TYPE;

	SPI_START;
	SPI_Transmit(bytes >> 8);
	SPI_Transmit(bytes & 0x00FF);
	SPI_STOP;
}

static void SH_reset(void)
{
	PORT_CLR(SH_RES_PIN);
	_delay_ms(1);
	PORT_SET(SH_RES_PIN);
	_delay_ms(120);
}

static void SH_clearRam(void)
{
	for (uint16_t i = 0; i < (SH_WIDTH / 2) * SH_HEIGHT; i++)
		sh_buffer[i] = 0;
	
	SH_Update();
}

void SH_Init(void)
{
	for (uint8_t i = 0; i < 15; i++)
		grayScale[i] = i;
	
	DDR_SET(SH_RES_PIN);
	DDR_SET(SH_DC_PIN);
	PORT_SET(SH_RES_PIN);
	
	SH_reset();
	
	SH_setContrast(128);
	SH_setDispReverse(0);
	SH_setOffset(0);
	
	SH_clearRam();
	SH_setPower(POWER_ON);
}

void SH_setColumnAdr(uint8_t column)
{
	column &= 0x7F;
	uint8_t ch = (column >> 4) | 0x10;
	uint8_t cl = column & 0x0F;
	
	SH_transmit2bytes((ch << 8) | cl, COMM);
}

void SH_setDispStartLine(uint8_t line)
{
	line &= 0x3F;
	SH_transmit1byte(line | 0x40, COMM);
}

void SH_setContrast(uint8_t contrast)
{
	uint8_t cmd = 0x81;
	SH_transmit2bytes((cmd << 8) | contrast, COMM);
}

void SH_setEntireDisp(uint8_t state)
{
	state &= 0x01;
	SH_transmit1byte(0xA4 | state, COMM);
}

void SH_setDispReverse(uint8_t mode)
{
	mode &= 0x01;
	SH_transmit1byte(0xA6 | mode, COMM);
}

void SH_setMultiplexRatMode(uint8_t ratmode)
{
	ratmode &= 0x3F;
	
	uint8_t mode_set = 0xA8;
	SH_transmit2bytes((mode_set << 8) | ratmode, COMM);
}

void SH_setPower(uint8_t power)
{
	power &= 0x01;
	SH_transmit1byte(0xAE | power, COMM);
}

void SH_setOffset(uint8_t offset)
{
	offset &= 0x3F; 
	
	uint8_t mode_set = 0xD3;
	SH_transmit2bytes((mode_set << 8) | offset, COMM);
}

void SH_putPixel(uint16_t x, uint16_t y, uint8_t color)
{
	if ((x % 2) == 0)
		sh_buffer[(y + x*SH_WIDTH) / 2] = color & 0xF0;
	else
		sh_buffer[(y + x*SH_WIDTH) / 2] = color & 0x0F;
}

void SH_Update(void)
{
	SPI_START;
	SH_DATA_TYPE;
	
	for (uint16_t i = 0; i < (SW_WIDTH * SH_HEIGHT / 2); i++)
		SPI_Transmit(sh_buffer[i])
 
	SPI_STOP;
}

void SH_drawRectangle(uint16_t x0, uint16_t y0, uint16_t width, uint16_t height, uint8_t color)
{
	for (uint16_t i = x0; i < width; i++)
		for (uint16_t j = y0; j < height; j++)
			SH_putPixel(i, j, color);
}

void SH_drawChar(uint16_t x, uint16_t y, char ch)
{
	