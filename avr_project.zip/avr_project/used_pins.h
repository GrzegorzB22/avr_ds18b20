/*
 * used_pins.h
 *
 *  Created on: 9 wrz 2024
 *      Author: re-gb
 */

#ifndef USED_PINS_H_
#define USED_PINS_H_


#define GLUE(x, y)	x##y

#define DDR_SET(x, y)	GLUE(DDR, x) |= y
#define DDR_RST(x, y)	GLUE(DDR, x) &= ~y

#define PORT_SET(x, y) GLUE(PORT, x) |= y
#define PORT_RST(x, y) GLUE(PORT, x) &= ~y

#define PIN_READ(x, y) GLUE(PIN, x) & y

#define SPI_SCK_PIN  B, 5
#define SPI_MISO_PIN B, 4
#define SPI_MOSI_PIN B, 3
#define SPI_CS_PIN   B, 2

#define SH_RES_PIN B, 1
#define SH_DC_PIN  B, 0

#endif /* USED_PINS_H_ */
