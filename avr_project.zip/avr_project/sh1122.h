/*
 * disp.h
 *
 *  Created on: 9 wrz 2024
 *      Author: re-gb
 */

// SH1122

#ifndef SH1122_H_
#define SH1122_H_

#include "used_pins.h"

#define SH_DATA_TYPE	PORT_SET(SH_DC_PIN)
#define SH_COMM_TYPE	PORT_RST(SH_DC_PIN)


#define SH_WIDTH  256
#define SH_HEIGHT 64

extern uint8_t grayScale[15];

#define GRAY_SCALE_0  grayScale[0]
#define GRAY_SCALE_1  grayScale[1]
#define GRAY_SCALE_2  grayScale[2]
#define GRAY_SCALE_3  grayScale[3]
#define GRAY_SCALE_4  grayScale[4]
#define GRAY_SCALE_5  grayScale[5]
#define GRAY_SCALE_6  grayScale[6]
#define GRAY_SCALE_7  grayScale[7]
#define GRAY_SCALE_8  grayScale[8]
#define GRAY_SCALE_9  grayScale[9]
#define GRAY_SCALE_10 grayScale[10]
#define GRAY_SCALE_11 grayScale[11]
#define GRAY_SCALE_12 grayScale[12]
#define GRAY_SCALE_13 grayScale[13]
#define GRAY_SCALE_14 grayScale[14]
#define GRAY_SCALE_15 grayScale[15]

void SH_setColumnAdr(uint8_t column);
void SH_setDispStartLine(uint8_t line);
void SH_setContrast(uint8_t contrast);
//void SH_setSegRemap(int remap);
void SH_setEntireDisp(uint8_t state);
void SH_setDispReverse(uint8_t mode);
void SH_setMultiplexRatMode(uint8_t ratmode);
//void SH_setDCMode(int dcmode);
void SH_setPower(uint8_t power);
void SH_setOffset(uint8_t offset);
void SH_putPixel(uint16_t x, uint16_t y, uint8_t color);
void SH_drawRectangle(uint16_t x0, uint16_t y0, uint16_t width, uint16_t height, uint8_t color);
void SH_Update(void);


void SH_Init(void);
void SH_drawChar(uint16_t x, uint16_t y, char ch);


#endif /* SH1122_H_ */
