

#include <avr/io.h>
#include "used_pins.h"
#include "sh1122.h"
#include "spi.h"

int main(void)
{
    SPI_Init();
	SH_Init();
	SH_drawRectangle(0, 0, 10, 20, GRAY_SCALE_10);
	SH_Update();
	
    while (1) 
    {
    }
}

