/*
 * sh1122.h
 *
 *  Created on: Sep 14, 2024
 *      Author: Admin
 */

#ifndef INC_SH1122_H_
#define INC_SH1122_H_


#include "main.h"
#include "spi.h"
#include "used_pins.h"

#define sh1122_spi hspi2
extern SPI_HandleTypeDef sh1122_spi;

#define NUM 0
#define LET 1

#define DAYS_INDEX 0
#define HRS_INDEX  1
#define MIN_INDEX  2
#define SEC_INDEX  3

#define SH_WIDTH 256
#define SH_HEIGHT 64

#define SH_DATA_PROCESS HAL_GPIO_WritePin(SH_DC_PORT, SH_DC_PIN, GPIO_PIN_SET)
#define SH_CMD_PROCESS  HAL_GPIO_WritePin(SH_DC_PORT, SH_DC_PIN, GPIO_PIN_RESET)

#define SPI_START		HAL_GPIO_WritePin(SPI_CS_PORT, SPI_CS_PIN, GPIO_PIN_RESET)
#define SPI_STOP		HAL_GPIO_WritePin(SPI_CS_PORT, SPI_CS_PIN, GPIO_PIN_SET)

#define FONT_16x16_SIZE 0
#define FONT_16x32_SIZE 1

void SH_setColumn(uint8_t column);
void SH_setDispLine(uint8_t line);
void SH_setContrast(uint8_t contrast);
void SH_setRemap(uint8_t remap);
void SH_setEntireDisp(uint8_t state);
void SH_setDispMode(uint8_t mode);
void SH_setOffset(uint8_t offset);
void SH_setDispPower(uint8_t power);
void SH_putPixel(int x, int y, uint8_t color);
void SH_drawRectangle(int x0, int y0, int width, int height, uint8_t color);
void SH_drawHLine(int x0, int y, int width, uint8_t color);
void SH_drawVLine(int x,  int y0, int height, uint8_t color);
void SH_setRowAdr(uint8_t row);
void SH_setScanDirection(uint8_t direction);

void SH_init(void);
void SH_update(void);
void SH_drawChar(int x, int y, uint8_t ch, uint8_t color, int font_size);
void SH_drawString(int x, int y, char *s, uint8_t color, int font_size);
void SH_clear(void);

void SH_displayTime(int days, int hrs, int min, int sec);
void SH_timeSettings(void);



#endif /* INC_SH1122_H_ */
