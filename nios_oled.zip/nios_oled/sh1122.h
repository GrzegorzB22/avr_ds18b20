/*
 * sh1106.h
 *
 *  Created on: 11 wrz 2024
 *      Author: re-gb
 */

#ifndef SH1122_H_
#define SH1122_H_

#include <alt_types.h>
#include <altera_avalon_pio_regs.h>
#include <system.h>

#define NUM  0
#define CHAR 1
#define NONE 3

#define SH_WIDTH 256
#define SH_HEIGHT 64

#define SH_DATA_PROCESS IOWR_ALTERA_AVALON_PIO_DATA(PIO_BASE, 0xFF)
#define SH_CMD_PROCESS  IOWR_ALTERA_AVALON_PIO_DATA(PIO_BASE, 0x00)

#define SPI_START		IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, 0x00)
#define SPI_STOP		IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, 0xFF)

void SH_setColumn(alt_u8 column);
void SH_setDispLine(alt_u8 line);
void SH_setContrast(alt_u8 contrast);
void SH_setRemap(alt_u8 remap);
void SH_setEntireDisp(alt_u8 state);
void SH_setDispMode(alt_u8 mode);
void SH_setOffset(alt_u8 offset);
void SH_setDispPower(alt_u8 power);
void SH_putPixel(alt_u16 x, alt_u16 y, alt_u8 color);
void SH_drawRectangle(alt_u16 x0, alt_u16 y0, alt_u16 width, alt_u16 height, alt_u8 color);
void SH_drawHLine(alt_u16 x0, alt_u16 y,  alt_u16 width, alt_u8 color);
void SH_drawVLine(alt_u16 x,  alt_u16 y0, alt_u16 height, alt_u8 color);
void SH_setRowAdr(alt_u8 row);

void SH_init(void);
void SH_update(void);
void SH_clear(void);
void SH_drawChar(alt_u16 x, alt_u16 y, alt_u8 ch, alt_u8 color);
void SH_drawString(alt_u16 x, alt_u16 y, char *s, alt_u8 color, alt_u8 size);

void SH_displayTime(alt_u16 d, alt_u8 h, alt_u8 m, alt_u8 s);
void SH_background(alt_u8 color);

void SH_sleep(void);

void Delay_us(alt_u16 us);
void Delay_ms(alt_u16 ms);

#endif /* SH1122_H_ */
