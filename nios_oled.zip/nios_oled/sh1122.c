
#include "sh1122.h"
#include <alt_types.h>
#include <altera_avalon_spi_regs.h>
#include <altera_avalon_spi.h>
#include <unistd.h>
#include <stdio.h>

//static alt_u8 sh_buffer[SH_WIDTH][SH_HEIGHT];
static alt_u8 sh_buffer[SH_WIDTH * SH_HEIGHT / 2];

void Delay_us(alt_u16 us)
{
	usleep(us);
}

void Delay_ms(alt_u16 ms)
{
	for (alt_u16 i = 0; i < ms; i++)
		Delay_us(1000);
}

static void SH_cmdb(alt_u8 cmd)
{
	SH_CMD_PROCESS;
	IOWR_ALTERA_AVALON_SPI_TXDATA(SPI_BASE, cmd);
	printf(", byte sent: %d\n", cmd);
}

static void SH_cmdbb(alt_u8 cmd_h, alt_u8 cmd_l)
{
	SH_CMD_PROCESS;
	IOWR_ALTERA_AVALON_SPI_TXDATA(SPI_BASE, cmd_h);
	Delay_us(100);
	IOWR_ALTERA_AVALON_SPI_TXDATA(SPI_BASE, cmd_l);
	printf(", byte sent: %d\n", cmd_h|cmd_l);
}


static void SH_rst(void)
{
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x00);
	Delay_us(200);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x01);
	Delay_ms(200);
}

static void SH_clrRAM(void)
{
	SH_DATA_PROCESS;
	Delay_ms(100);

	for (alt_u16 i = 0; i < SH_HEIGHT; i++)
		for (alt_u16 j = 0; j < SH_WIDTH; j++) {
			SH_putPixel(j, i, 0x00);
			//Delay_us(100);
		}

	SH_update();
}

void SH_background(alt_u8 color)
{
	for (alt_u16 i = 0; i < SH_WIDTH; i++)
		for (alt_u16 j = 0; j < SH_HEIGHT; j++)
			SH_putPixel(i, j, color);

	SH_update();
}

void SH_putPixel(alt_u16 x, alt_u16 y, alt_u8 color)
{
	if ((x & 0x01) == 0) {
		sh_buffer[(x + y*SH_WIDTH) / 2] &= 0x0F;
		sh_buffer[(x + y*SH_WIDTH) / 2] |= ((color & 0x0F) << 4);
	}
	else {
		sh_buffer[(x + y*SH_WIDTH) / 2] &= 0xF0;
		sh_buffer[(x + y*SH_WIDTH) / 2] |= (color & 0x0F);
	}
}

void SH_update(void)
{

	SH_setRowAdr(0);
	SH_setColumn(0);
	//SH_setDispLine(0);

	SH_DATA_PROCESS;
	Delay_ms(100);

	SPI_START;

	alt_avalon_spi_command(SPI_BASE, 0,
	                           SH_WIDTH * SH_HEIGHT / 2, sh_buffer,
	                           0, NULL,
	                           0);

	SPI_STOP;
}

void SH_init(void)
{
	SH_rst();

	//SH_setContrast(200);
	SH_clrRAM();
	SH_setDispPower(1);
	Delay_ms(100);
}

void SH_setColumn(alt_u8 column)
{
	column &= 0x7F;
	alt_u8 col_h = (column >> 4) | 0x10;
	alt_u8 col_l = column & 0x0F;

	SPI_START;
	SH_cmdbb(col_h, col_l);
	SPI_STOP;
}

void SH_setDispLine(alt_u8 line)
{
	line &= 0x3F;

	SPI_START;
	SH_cmdb(line);
	SPI_STOP;
}

void SH_setContrast(alt_u8 contrast)
{
	alt_u8 contrast_msb = 0x81;

	SPI_START;
	SH_cmdbb(contrast_msb, contrast);
	SPI_STOP;
}

void SH_setRemap(alt_u8 remap)
{
	remap &= 0x01;

	SPI_START;
	SH_cmdb(remap | 0xA0);
	SPI_STOP;
}

void SH_setEntireDisp(alt_u8 state)
{
	state &= 0x01;

	SPI_START;
	SH_cmdb(state | 0xA4);
	SPI_STOP;
}

void SH_setDispMode(alt_u8 mode)
{
	mode &= 0x01;

	SPI_START;
	SH_cmdb(mode | 0xA6);
	SPI_STOP;
}

void SH_setDispPower(alt_u8 power)
{
	power &= 0x01;

	SPI_START;
	SH_cmdb(power | 0xAE);
	SPI_STOP;
}

void SH_setOffset(alt_u8 offset)
{
	alt_u8 offset_msb = 0xD3;
	offset &= 0x3F;

	SPI_START;
	SH_cmdbb(offset_msb, offset);
	SPI_STOP;
}

void SH_drawHLine(alt_u16 x0, alt_u16 y,  alt_u16 width, alt_u8 color)
{
	for (alt_u16 i = 0; i < width; i++)
		SH_putPixel(i + x0, y, color);
}

void SH_drawVLine(alt_u16 x,  alt_u16 y0, alt_u16 height, alt_u8 color)
{
	for (alt_u16 i = 0; i < height; i++)
		SH_putPixel(x, i + y0, color);
}

void SH_drawRectangle(alt_u16 x0, alt_u16 y0, alt_u16 width, alt_u16 height, alt_u8 color)
{
	SH_drawHLine(x0, y0, width, color);
	SH_drawHLine(x0, y0 + height, width, color);

	SH_drawVLine(x0, y0, height, color);
	SH_drawVLine(x0 + width, y0, height, color);
}

void SH_setRowAdr(alt_u8 row)
{
	alt_u8 row_msb = 0xB0;
	row &= 0x3F;

	SPI_START;
	SH_cmdbb(row_msb, row);
	SPI_STOP;
}

void SH_drawChar(alt_u16 x, alt_u16 y, alt_u32 *ch, alt_u8 color, alt_u8 type)
{
	alt_u8 width_limit, height_limit;
	if (type == NUM) {
		width_limit = 24;
		height_limit = 32;
	}
	else {
		width_limit = 8;
		height_limit = 8;
	}

	alt_u32 line;

	for (alt_u8 i = 0; i < width_limit; i++) {
		line = ch[i];
		for (alt_u8 j = 0; j < height_limit; j++) {
			if (line & (1 << j)) SH_putPixel(i + x, j + y, color);
		}
	}
}
