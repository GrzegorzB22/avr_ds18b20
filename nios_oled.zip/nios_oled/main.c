/* 
 * "Small Hello World" example. 
 * 
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example 
 * designs. It requires a STDOUT  device in your system's hardware. 
 *
 * The purpose of this example is to demonstrate the smallest possible Hello 
 * World application, using the Nios II HAL library.  The memory footprint
 * of this hosted application is ~332 bytes by default using the standard 
 * reference design.  For a more fully featured Hello World application
 * example, see the example titled "Hello World".
 *
 * The memory footprint of this example has been reduced by making the
 * following changes to the normal "Hello World" example.
 * Check in the Nios II Software Developers Manual for a more complete 
 * description.
 * 
 * In the SW Application project (small_hello_world):
 *
 *  - In the C/C++ Build page
 * 
 *    - Set the Optimization Level to -Os
 * 
 * In System Library project (small_hello_world_syslib):
 *  - In the C/C++ Build page
 * 
 *    - Set the Optimization Level to -Os
 * 
 *    - Define the preprocessor option ALT_NO_INSTRUCTION_EMULATION 
 *      This removes software exception handling, which means that you cannot 
 *      run code compiled for Nios II cpu with a hardware multiplier on a core 
 *      without a the multiply unit. Check the Nios II Software Developers 
 *      Manual for more details.
 *
 *  - In the System Library page:
 *    - Set Periodic system timer and Timestamp timer to none
 *      This prevents the automatic inclusion of the timer driver.
 *
 *    - Set Max file descriptors to 4
 *      This reduces the size of the file handle pool.
 *
 *    - Check Main function does not exit
 *    - Uncheck Clean exit (flush buffers)
 *      This removes the unneeded call to exit when main returns, since it
 *      won't.
 *
 *    - Check Don't use C++
 *      This builds without the C++ support code.
 *
 *    - Check Small C library
 *      This uses a reduced functionality C library, which lacks  
 *      support for buffering, file IO, floating point and getch(), etc. 
 *      Check the Nios II Software Developers Manual for a complete list.
 *
 *    - Check Reduced device drivers
 *      This uses reduced functionality drivers if they're available. For the
 *      standard design this means you get polled UART and JTAG UART drivers,
 *      no support for the LCD driver and you lose the ability to program 
 *      CFI compliant flash devices.
 *
 *    - Check Access device drivers directly
 *      This bypasses the device file system to access device drivers directly.
 *      This eliminates the space required for the device file system services.
 *      It also provides a HAL version of libc services that access the drivers
 *      directly, further reducing space. Only a limited number of libc
 *      functions are available in this configuration.
 *
 *    - Use ALT versions of stdio routines:
 *
 *           Function                  Description
 *        ===============  =====================================
 *        alt_printf       Only supports %s, %x, and %c ( < 1 Kbyte)
 *        alt_putstr       Smaller overhead than puts with direct drivers
 *                         Note this function doesn't add a newline.
 *        alt_putchar      Smaller overhead than putchar with direct drivers
 *        alt_getchar      Smaller overhead than getchar with direct drivers
 *
 */

#include <system.h>
#include <altera_avalon_spi_regs.h>
#include <altera_avalon_spi.h>
#include <altera_avalon_pio_regs.h>
#include "sh1122.h"
#include <altera_avalon_timer.h>
#include <altera_avalon_timer_regs.h>
#include <stdio.h>

typedef enum {
	START   = 0,
	STATE_A = 1,
	STATE_B = 2,
	STATE_C = 3,
	STATE_D = 4,
	STATE_E = 5,
	STATE_F = 6,
	STATE_G = 7,
	STATE_H = 8,
	STATE_I = 9,
	STATE_J = 10,
	STATE_K = 11,
	STATE_L = 12
} state_machine;

#define ENC_BUT_PIO PIO_4_BASE
#define ENC_A_PIO   PIO_0_BASE
#define ENC_B_PIO   PIO_3_BASE

static volatile alt_u8 timer_flag = 0;
static int enc_direction = 0;

void readEncoder(void);
int returnEncoderValue(void);
void timer_init(void);

void timerIRQ(void *context, alt_u32 id)
{
	IOWR_ALTERA_AVALON_TIMER_STATUS(TIMER_BASE, 0);
	timer_flag = 1;
}

int main()
{ 

	SH_init();

	timer_init();

	int sh_sleep_counter = 0;
	int sh_sleep_reset = 0;
	int sh_sleep_status = 0;
	int print = 0;

	alt_u16 state_a_counter = 0;
	alt_u16 state_d_counter = 0;

	int button_counter = 0;
	int last_button = 0xFF;
	int button;
	int button_clicked = 0;
	int i =0;
	char x = 'C';

	state_machine state = START;
	SH_clear();
	SH_drawChar(0, 0, x, 15);
	SH_update();

	while (1) {
		if (timer_flag == 1) {

			if (sh_sleep_reset == 1) {
				sh_sleep_reset = 0;
				sh_sleep_counter = 0;
				if (sh_sleep_status == 1) {
					sh_sleep_status = 0;
					SH_setDispPower(1);
				}
			}
			else {
				sh_sleep_counter++;
				if ((sh_sleep_status == 0) && (sh_sleep_counter == 10000)) {
					sh_sleep_status = 1;
					sh_sleep_counter = 0;
					SH_setDispPower(0);
				}
			}

			timer_flag = 0;

			if ((state_a_counter != 0) || (state_d_counter != 0) || (button_clicked == 1) || (returnEncoderValue() != 0)) sh_sleep_reset = 1;

			//printf("%d\n", state_a_counter);

			if (button_counter == 0) {
				button = IORD_ALTERA_AVALON_PIO_DATA(ENC_BUT_PIO);
				if ((last_button ^ button) && (button == 0)) {
					button_counter = 200;
					button_clicked = 1;
				}
				last_button = button;
			}
			else button_counter--;

			switch (state) {

			case START:
				if (sh_sleep_status == 1) {
					if ((button_clicked == 1) || (returnEncoderValue() != 0)) {
						button_clicked = 0;
						state = STATE_A;
					}
				}
				else {
					if (button_clicked == 1) {
						state = STATE_C;
						button_clicked = 0;
					}
					else if (returnEncoderValue() != 0) state = STATE_D;
				}
				break;

			case STATE_A:
				// LEDY NA CZERWONO
				if (print == 0) {
					SH_clear();
					SH_drawString(0, 0, "LEDY CZERWONO", 15, 1);
					SH_drawString(100, 20, "LOSOWY TEKST A", 15, 1);
					SH_update();
					print = 1;
				}
				state_a_counter++;
				if (state_a_counter == 60000) {
					state_a_counter = 0;
					state = STATE_B;
					print = 0;
				}
				break;

			case STATE_B:
				SH_clear();
				SH_drawString(100, 20, "BATERIA", 15, 1);
				SH_update();
				state = START;
				break;

			case STATE_C:
				SH_clear();
				// OTWARCIE PUDLA
				SH_drawString(0, 30, "LOSOWY TEKST B", 15, 1);
				SH_update();
				state = START;
				break;

			case STATE_D:
				// LEDY ZIELONO
				if (print == 0) {
					SH_clear();
					SH_drawString(0, 30, "Nacisnij, aby otworzyc", 15, 1);
					SH_update();
					print = 1;
				}
				state_d_counter++;
				if (state_d_counter < 20000) {
					if (button_clicked == 1) {
						button_clicked = 0;
						state_d_counter = 0;
						state = STATE_C;
						print = 0;
					}
				}
				else {
					state_d_counter = 0;
					state = STATE_E;
					print = 0;
				}
			}



			//printf("%d\n", i);
		}
	}
	return 0;
}

void timer_init(void)
{
	alt_irq_register(TIMER_IRQ, NULL, timerIRQ);

	IOWR_ALTERA_AVALON_TIMER_CONTROL (TIMER_BASE,
			ALTERA_AVALON_TIMER_CONTROL_ITO_MSK  |
			ALTERA_AVALON_TIMER_CONTROL_CONT_MSK |
			ALTERA_AVALON_TIMER_CONTROL_START_MSK);
}

void readEncoder(void)
{
	int enc_position;
	static int enc_last_position = 0;

	static int enc_counter[2] = {0};
	int current_enc[2]        = {0};
	static int last_enc[2]    = {0};

	if (enc_counter[0] == 0) {
		current_enc[0] = IORD_ALTERA_AVALON_PIO_DATA(ENC_A_PIO);
		if ((last_enc[0] ^ current_enc[0]) && (current_enc[0] == 0)) enc_counter[0] = 200;
		last_enc[0] = current_enc[0];
	}

	if (enc_counter[1] == 0) {
		current_enc[1] = IORD_ALTERA_AVALON_PIO_DATA(ENC_B_PIO);
		if ((last_enc[1] ^ current_enc[1]) && (current_enc[1] == 0)) enc_counter[1] = 200;
		last_enc[1] = current_enc[1];
	}

	for (int c = 0; c < 2; c++) {
		if (enc_counter[c]) enc_counter[c]--;
	}


	enc_position = 0;
	if (IORD_ALTERA_AVALON_PIO_DATA(ENC_A_PIO) == 0) enc_position |= 0x01;
	if (IORD_ALTERA_AVALON_PIO_DATA(ENC_B_PIO) == 0) enc_position |= 0x02;

	switch (enc_position) {

	case 0:
		if (enc_last_position == 1) 		enc_direction++;
		else if (enc_last_position == 2)	enc_direction--;
		break;

	case 1:
		if (enc_last_position == 3)			enc_direction++;
		else if (enc_last_position == 0)	enc_direction--;
		break;

	case 2:
		if (enc_last_position == 0)			enc_direction++;
		else if (enc_last_position == 3)	enc_direction--;
		break;

	case 3:
		if (enc_last_position == 2)			enc_direction++;
		else if (enc_last_position == 1)	enc_direction--;
		break;
	}
	enc_last_position = enc_position;
}

int returnEncoderValue(void)
{
	readEncoder();
	int val = enc_direction;
	enc_direction = val & 3;
	return val >> 2;
}
