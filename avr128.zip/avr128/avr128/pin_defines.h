
#ifndef PIN_DEFINES_H_
#define PIN_DEFINES_H_

#include <avr/io.h>

/***********************************PINY SPI****************************/
#define SPI_MOSI_PORT PORTA
#define SPI_MOSI_PIN  PIN4_bm

#define SPI_SCK_PORT  PORTA
#define SPI_SCK_PIN   PIN6_bm

#define SPI_CS_PORT PORTA
#define SPI_CS_PIN  PIN7_bm
/***********************************************************************/

/*******************************PINY WYSWIETLACZA***********************/
#define SH_DC_PORT PORTD
#define SH_DC_PIN  PIN0_bm

#define SH_RST_PORT PORTD
#define SH_RST_PIN  PIN1_bm
/***********************************************************************/

/********************************PINY ENKODERA**************************/
#define ENC_A_PORT  PORTD
#define ENC_A_PIN   PIN2_bm

#define ENC_B_PORT  PORTD
#define ENC_B_PIN   PIN3_bm

#define ENC_SW_PORT PORTD
#define ENC_SW_PIN  PIN4_bm

#define ENC_A_CTRL  PIN2CTRL
#define ENC_B_CTRL  PIN3CTRL
#define ENC_SW_CTRL PIN4CTRL
/***********************************************************************/

#define LED_RED_PORT PORTD
#define LED_RED_PIN  PIN5_bm

#define LED_GREEN_PORT PORTD
#define LED_GREEN_PIN PIN6_bm

#define DEVICE_PORT PORTC
#define DEVICE_PIN PIN0_bm

#endif /* PIN_DEFINES_H_ */