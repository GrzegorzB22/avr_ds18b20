/*
 * sh1122.h
 *
 * Created: 05.11.2024 11:23:45
 *  Author: re-gb
 */ 


#ifndef SH1122_H_
#define SH1122_H_

#include <avr/io.h>
#include "pin_defines.h"

#define X_START 0
#define X_P     32
#define X_I     112
#define X_D     192

#define Y_OFFSET 30

#define NUM     0
#define CHAR    1
#define BAT_0   2
#define BAT_20  3
#define BAT_40  4
#define BAT_60  5
#define BAT_80  6
#define BAT_100 7
#define BAT     8
#define LOGO    9
#define NONE    20

#define SH_WIDTH 256
#define SH_HEIGHT 64

#define SH_DATA_PROCESS SH_DC_PORT.OUT |= SH_DC_PIN
#define SH_CMD_PROCESS  SH_DC_PORT.OUT &= ~SH_DC_PIN

void SH_setColumn(uint8_t column);
void SH_setDispLine(uint8_t line);
void SH_setContrast(uint8_t contrast);
void SH_setRemap(uint8_t remap);
void SH_setEntireDisp(uint8_t state);
void SH_setDispMode(uint8_t mode);
void SH_setOffset(uint8_t offset);
void SH_setDispPower(uint8_t power);
void SH_putPixel(uint16_t x, uint16_t y, uint8_t color);
void SH_setRowAdr(uint8_t row);

void SH_init(void);
void SH_update(void);
void SH_clear(void);
void SH_drawChar(uint16_t x, uint16_t y, uint8_t ch, uint8_t color);
void SH_drawString(uint16_t x, uint16_t y, char *s, uint8_t color);
void SH_changeColorAll(uint8_t color);


#endif /* SH1122_H_ */