
#include "pin_defines.h"
#include <avr/io.h>
#include "encoder.h"

static int enc_direction = 0;
static uint8_t button_pushed = 0;

void Encoder_init(void)
{	ENC_A_PORT.ENC_A_CTRL = ENC_B_PORT.ENC_B_CTRL = ENC_SW_PORT.ENC_SW_CTRL = 0x08;
	ENC_A_PORT.DIRCLR = ENC_A_PIN;
	ENC_B_PORT.DIRCLR = ENC_B_PIN;
	ENC_SW_PORT.DIRCLR = ENC_SW_PIN;
}

void readEncoder(void)
{
	uint8_t enc_position;
	static uint8_t enc_last_position = 0;

	static uint8_t enc_counter[2] = {0};
	uint8_t current_enc;
	static uint8_t last_current_enc = 0xFF;

	if (enc_counter[0] == 0) {
		current_enc = ENC_A_PORT.IN;
		if (((current_enc ^ last_current_enc) & ENC_A_PIN) && ((current_enc & ENC_A_PIN) == 0)) enc_counter[0] = DEBOUNCING_TIME_MS;
		last_current_enc &= ~ENC_A_PIN;
		last_current_enc |= (current_enc & ENC_A_PIN);
	}
	
	if (enc_counter[1] == 0) {
		current_enc = ENC_B_PORT.IN;
		if (((current_enc ^ last_current_enc) & ENC_B_PIN) && ((current_enc & ENC_B_PIN) == 0)) enc_counter[1] = DEBOUNCING_TIME_MS;
		last_current_enc &= ~ENC_B_PIN;
		last_current_enc |= (current_enc & ENC_B_PIN);
	}

	for (uint8_t c = 0; c < 2; c++) {
		if (enc_counter[c]) enc_counter[c]--;
	}


	enc_position = 0;
	if ((ENC_A_PORT.IN & ENC_A_PIN) == 0) enc_position |= 0x01;
	if ((ENC_B_PORT.IN & ENC_B_PIN) == 0) enc_position |= 0x02;

	switch (enc_position) {

		case 0:
		if (enc_last_position == 1) 		enc_direction++;
		else if (enc_last_position == 2)	enc_direction--;
		break;

		case 1:
		if (enc_last_position == 3)			enc_direction++;
		else if (enc_last_position == 0)	enc_direction--;
		break;

		case 2:
		if (enc_last_position == 0)			enc_direction++;
		else if (enc_last_position == 3)	enc_direction--;
		break;

		case 3:
		if (enc_last_position == 2)			enc_direction++;
		else if (enc_last_position == 1)	enc_direction--;
		break;
	}
	enc_last_position = enc_position;
}

int returnEncoderValue(void)
{
	int val = enc_direction;
	enc_direction = val & 3;
	return val >> 2;
}

void readButton(void)
{
	static uint8_t counter = 0;
	static uint8_t last_but = 0xFF;
	uint8_t but;
	
	if (counter == 0) {
		but = ENC_SW_PORT.IN;
		if (((but ^ last_but) & ENC_SW_PIN) && ((but & ENC_SW_PIN) == 0)) {
			counter = 100;
			button_pushed = 1;
		}
		last_but = but;
	}
	else counter--;
}

uint8_t returnButton(void)
{
	uint8_t val = button_pushed;
	button_pushed = 0;
	return val;
}

