

#ifndef BOX_H_
#define BOX_H_

#include <avr/io.h>

#define DEVICE_L   0  // urzadzenie zablokowane
#define DEVICE_ULL 1  // urzadzenie odblokowane ale mechanicznie zablokowane
#define DEVICE_UL  2  // urzadzenie odblokowane

#define BATTERY_LOW  0
#define BATTERY_NLOW 1

#define DISPLAY_TIME_L  0
#define DISPLAY_TIME_UL 1

typedef struct {
	uint16_t days;
	uint8_t hours;
	uint8_t minutes;
	uint8_t seconds;	
} box_time;

void BOX_displayTime(box_time *x, uint8_t time_flag);
void BOX_displayAnimation(void);
void BOX_displayState(uint8_t state);
void BOX_displayLockTimer(volatile uint8_t timer);

#endif 