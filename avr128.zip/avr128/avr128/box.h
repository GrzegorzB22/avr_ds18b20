

#ifndef BOX_H_
#define BOX_H_

#include <avr/io.h>

#define DEVICE_L   0  // urzadzenie zablokowane
#define DEVICE_ULL 1  // urzadzenie odblokowane ale mechanicznie zablokowane
#define DEVICE_UL  2  // urzadzenie odblokowane

void BOX_displayTime(uint16_t days, uint8_t hours, uint8_t minutes, uint8_t seconds);

#endif 