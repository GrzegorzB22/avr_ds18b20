
#include "sh1122.h"
#include "pin_defines.h"
#include <avr/io.h>
#include <stdlib.h>
#include <string.h>

void BOX_displayTime(uint16_t days, uint8_t hours, uint8_t minutes, uint8_t seconds)
{
	char str[10] = {0};
	uint8_t x = 20;
	const uint8_t y = SH_HEIGHT / 2;
	
	if (days) {
		SH_drawString(x, y, itoa(days, str, 10), 15);
		x += (strlen(str) * 8);
		
		SH_drawChar(x, y, ':', 15);
		x += 8;
		
		SH_drawString(x, y, itoa(hours, str, 10), 15);
		x += (strlen(str) * 8);
		
		SH_drawChar(x, y, ':', 15);
		x += 8;
		
		SH_drawString(x, y, itoa(minutes, str, 10), 15);
	}
	else {
		SH_drawString(x, y, itoa(hours, str, 10), 15);
		x += (strlen(str) * 8);
		
		SH_drawChar(x, y, ':', 15);
		x += 8;
		
		SH_drawString(x, y, itoa(minutes, str, 10), 15);
		x += (strlen(str) * 8);
		
		SH_drawChar(x, y, ':', 15);
		x += 8;
		
		SH_drawString(x, y, itoa(seconds, str, 10), 15);
	}
	
	SH_update();
}