
#include "spi.h"
#include "pin_defines.h"
#include <avr/io.h>

void SPI_init(void)
{
	SPI_MOSI_PORT.DIR |= SPI_MOSI_PIN;
	SPI_SCK_PORT.DIR  |= SPI_SCK_PIN;
	SPI_CS_PORT.DIR   |= SPI_CS_PIN;
	SPI0.CTRLA = 0b00100011;
}

void SPI_transmit(uint8_t data)
{
	SPI0.DATA = data;
	while (!(SPI0.INTFLAGS & SPI_IF_bm))
		;
}

void SPI_transmitPacket(uint8_t data[], uint16_t n)
{
	for (uint16_t i = 0; i < n; i++) SPI_transmit(data[i]);
}