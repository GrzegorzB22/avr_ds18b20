
#include "sh1122.h"
#include "pin_defines.h"
#include <avr/io.h>
#include <stdlib.h>
#include "device.h"

#define X0 20
#define Yh SH_HEIGHT/2 - 16

static void device_displayDays(device_time *time, uint8_t font_size)
{
	
	uint8_t x = X0;
	uint8_t x_offset = 8;
	if (font_size == FONT_8x16) x_offset = 8;
	else if (font_size == FONT_16x32) x_offset = 16;
		
	if (time->days >= 100) {
		SH_drawChar(x, Yh, (time->days / 100) + '0', 15, font_size);
		x += x_offset;
		SH_drawChar(x, Yh, ((time->days / 10) % 10) + '0', 15, font_size);
		x += x_offset;
		SH_drawChar(x, Yh, (time->days % 10) + '0', 15, font_size);
		x += x_offset;
	}
	else {
		SH_drawChar(x, Yh, ((time->days / 10) % 10) + '0', 15, font_size);
		x += x_offset;
		SH_drawChar(x, Yh, (time->days % 10) + '0', 15, font_size);
		x += x_offset;
	}
	
	SH_drawChar(x, Yh, ':', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, (time->hours / 10) + '0', 15, font_size);
	x += x_offset;
	SH_drawChar(x, Yh, (time->hours % 10) + '0', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, ':', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, (time->minutes / 10) + '0', 15, font_size);
	x += x_offset;
	SH_drawChar(x, Yh, (time->minutes % 10) + '0', 15, font_size);
	
	x = X0;
	SH_drawString(x, Yh + 16, "DAYS", 15, font_size);
	x += 4*x_offset; // 4 litery z DAYS * 8
	SH_drawString(x, Yh + 16, "HRS", 15, font_size);
	x += 3*x_offset;
	SH_drawString(x, Yh + 16, "MIN", 15, font_size);
	
}

static void device_displayHours(device_time *time, uint8_t font_size)
{
	
	uint8_t x = X0;
	uint8_t x_offset = 8;
	if (font_size == FONT_8x16) x_offset = 8;
	else if (font_size == FONT_16x32) x_offset = 16;
	
	SH_drawChar(x, Yh, (time->hours / 10) + '0', 15, font_size);
	x += x_offset;
	SH_drawChar(x, Yh, (time->hours % 10) + '0', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, ':', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, (time->minutes / 10) + '0', 15, font_size);
	x += x_offset;
	SH_drawChar(x, Yh, (time->minutes % 10) + '0', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, ':', 15, font_size);
	x += x_offset;
	
	SH_drawChar(x, Yh, (time->seconds / 10) + '0', 15, font_size);
	x += x_offset;
	SH_drawChar(x, Yh, (time->seconds % 10) + '0', 15, font_size);
	
	x = X0;
	SH_drawString(x, Yh + 16, "HRS", 15, font_size);
	x += 3*x_offset;
	SH_drawString(x, Yh + 16, "MIN", 15, font_size);
	x += 3*x_offset;
	SH_drawString(x, Yh + 16, "SEC", 15, font_size);
	
}

void device_displayTime(device_time *time, uint8_t time_flag, uint8_t font_size)
{
	SH_clearXY(20, SH_HEIGHT/2-16, SH_WIDTH, SH_HEIGHT);
	if (time_flag == DEVICE_L) {
		if (time->days) device_displayDays(time, font_size);
		else device_displayHours(time, font_size);
	}
	else device_displayDays(time, font_size);
	SH_update();
}

void device_displayAnimation(void)
{
	
}

void device_displayState(uint8_t state)
{
	SH_clearXY(180, 0, 188, 16);
	switch (state) {
		case DEVICE_L:   SH_drawChar(180, 0, 'Z', 15, FONT_8x16); break;
		case DEVICE_UM: SH_drawChar(180, 0,  'M', 15, FONT_8x16); break;
		case DEVICE_UL:  SH_drawChar(180, 0, 'U', 15, FONT_8x16); break;
	}
	SH_update();
}