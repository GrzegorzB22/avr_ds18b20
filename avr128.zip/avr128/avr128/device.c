
#include "sh1122.h"
#include "pin_defines.h"
#include <avr/io.h>
#include <stdlib.h>
#include "device.h"

#define X0 20
#define Yh SH_HEIGHT/2

static void device_displayDays(device_time *time)
{
	uint8_t x = X0;
	 
	SH_drawChar(x, Yh, (time->days / 100) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, ((time->days / 10) % 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->days % 10) + '0', 15);
	x += 8;
	
	SH_drawChar(x, Yh, ':', 15);
	x += 8;
	
	SH_drawChar(x, Yh, (time->hours / 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->hours % 10) + '0', 15);
	x += 8;
	
	SH_drawChar(x, Yh, ':', 15);
	x += 8;
	
	SH_drawChar(x, Yh, (time->minutes / 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->minutes % 10) + '0', 15);
}

static void device_displayHours(device_time *time)
{
	uint8_t x = X0;
	
	SH_drawChar(x, Yh, (time->hours / 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->hours % 10) + '0', 15);
	x += 8;
	
	SH_drawChar(x, Yh, ':', 15);
	x += 8;
	
	SH_drawChar(x, Yh, (time->minutes / 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->minutes % 10) + '0', 15);
	x += 8;
	
	SH_drawChar(x, Yh, ':', 15);
	x += 8;
	
	SH_drawChar(x, Yh, (time->seconds / 10) + '0', 15);
	x += 8;
	SH_drawChar(x, Yh, (time->seconds % 10) + '0', 15);
}

void device_displayTime(device_time *time, uint8_t time_flag)
{
	SH_clearXY(0, SH_DEVICE_STATE_HEIGHT, SH_WIDTH, SH_HEIGHT - SH_DEVICE_STATE_HEIGHT);
	if (time_flag == DISPLAY_TIME_L) {
		if (time->days) device_displayDays(time);
		else device_displayHours(time);
	}
	else device_displayDays(time);
	SH_update();
}

void device_displayAnimation(void)
{
	
}

void device_displayState(uint8_t state)
{
	SH_clearXY(180, 0, SH_DEVICE_STATE_WIDTH, SH_DEVICE_STATE_HEIGHT);
	switch (state) {
		case DEVICE_L:   SH_drawChar(180, 0, 'Z', 15); break;
		case DEVICE_ULL: SH_drawChar(180, 0, 'M', 15); break;
		case DEVICE_UL:  SH_drawChar(180, 0, 'Z', 15); break;
	}
	SH_update();
}