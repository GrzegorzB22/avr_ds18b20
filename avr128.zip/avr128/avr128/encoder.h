/*
 * encoder.h
 *
 * Created: 06.11.2024 20:17:19
 *  Author: Admin
 */ 


#ifndef ENCODER_H_
#define ENCODER_H_

#include "pin_defines.h"
#include <avr/io.h>

#define DEBOUNCING_TIME_MS 100

void Encoder_init(void);
void readEncoder(void);
int returnEncoderValue(void);
void readButton(void);
uint8_t returnButton(void);



#endif /* ENCODER_H_ */