

#ifndef DEVICE_H_
#define DEVICE_H_

#include <avr/io.h>

#define DEVICE_L   0  // urzadzenie zablokowane
#define DEVICE_UL  1  // urzadzenie odblokowane ale mechanicznie zablokowane
#define DEVICE_UM 2  // urzadzenie odblokowane

#define BATTERY_LOW  0
#define BATTERY_NLOW 1

typedef struct {
	uint16_t days;
	uint8_t hours;
	uint8_t minutes;
	uint8_t seconds;	
} device_time;

void device_displayTime(device_time *x, uint8_t time_flag);
void device_displayAnimation(void);
void device_displayState(uint8_t state);
void device_openDevice(void);
void device_closeDevice(void);

#endif 