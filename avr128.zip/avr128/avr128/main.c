/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>

#define CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )

void Encoder_init(void);
void Timer_init(void);
void readEncoder(void);
int returnEncoderValue(void);

void putch(unsigned char data);

static volatile int enc_direction = 0;
static volatile uint8_t timer_flag = 0;

ISR(TCA0_OVF_vect)
{
	timer_flag = 1;
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CLOCK_16MHz_set;

	Timer_init();
	Encoder_init();
	SPI_init();
	SH_init();
	
	SH_clear();
	SH_drawChar(0, 0, '1', 15);
	SH_update();
	
	int timer_counter = 0;
	int button_counter = 0;
	uint8_t but;
	uint8_t last_but = 0xFF;
	int i = 0;
    while (1)
	{
		if (timer_flag == 1) {
			timer_flag = 0;
			timer_counter++;
			
			if (button_counter == 0) {
				but = ENC_SW_PORT.IN & ENC_SW_PIN;
				if ((last_but ^ but) && (but == 0)) {
					button_counter = 100;
				}
				last_but = but;
			}
			else button_counter--;
			
			SH_clear();
			switch (returnEncoderValue()) {
				case -1: SH_drawString(0, 0, "-1", 15); break;
				case 0 : SH_drawString(0, 0, "0", 15); break;
				case 1 : SH_drawString(0, 0, "1", 15); break;
			}
			SH_update();
		}
	}
}

void Timer_init(void)
{
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
	sei();
}

void Encoder_init(void)
{
	ENC_A_PORT.ENC_A_CTRL = ENC_B_PORT.ENC_B_CTRL = ENC_SW_PORT.ENC_SW_CTRL = 0x08;
	ENC_A_PORT.DIRCLR = ENC_A_PIN;
	ENC_B_PORT.DIRCLR = ENC_B_PIN;
	ENC_SW_PORT.DIRCLR = ENC_SW_PIN;
}

void readEncoder(void)
{
	uint8_t enc_position;
	static uint8_t enc_last_position = 0;

	static uint8_t enc_counter[2] = {0};
	uint8_t current_enc;
	static uint8_t last_current_enc = 0xFF;

	if (enc_counter[0] == 0) {
		current_enc = ENC_A_PORT.IN;
		if (((current_enc ^ last_current_enc) & ENC_A_PIN) && ((current_enc & ENC_A_PIN) == 0)) enc_counter[0] = 100;
		last_current_enc &= ~ENC_A_PIN;
		last_current_enc |= (current_enc & ENC_A_PIN);
	}
	
	if (enc_counter[1] == 0) {
		current_enc = ENC_B_PORT.IN;
		if (((current_enc ^ last_current_enc) & ENC_B_PIN) && ((current_enc & ENC_B_PIN) == 0)) enc_counter[1] = 100;
		last_current_enc &= ~ENC_B_PIN;
		last_current_enc |= (current_enc & ENC_B_PIN);
	}

	for (int c = 0; c < 2; c++) {
		if (enc_counter[c]) enc_counter[c]--;
	}


	enc_position = 0;
	if ((ENC_A_PORT.IN & ENC_A_PIN) == 0) enc_position |= 0x01;
	if ((ENC_B_PORT.IN & ENC_B_PIN) == 0) enc_position |= 0x02;

	switch (enc_position) {

		case 0:
		if (enc_last_position == 1) 		enc_direction++;
		else if (enc_last_position == 2)	enc_direction--;
		break;

		case 1:
		if (enc_last_position == 3)			enc_direction++;
		else if (enc_last_position == 0)	enc_direction--;
		break;

		case 2:
		if (enc_last_position == 0)			enc_direction++;
		else if (enc_last_position == 3)	enc_direction--;
		break;

		case 3:
		if (enc_last_position == 2)			enc_direction++;
		else if (enc_last_position == 1)	enc_direction--;
		break;
	}
	enc_last_position = enc_position;
}

int returnEncoderValue(void)
{
	readEncoder();
	int val = enc_direction;
	enc_direction = val & 3;
	return val >> 2;
}