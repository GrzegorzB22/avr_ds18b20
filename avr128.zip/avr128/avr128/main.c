/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"
#include <string.h>
#include "box.h"
#include "pin_defines.h"

#define DAYS_RATE 86400
#define HRS_RATE  3600
#define MIN_RATE  60

typedef enum {
	START, STATE_0, STATE_1, STATE_2, STATE_3, STATE_4, STATE_5, STATE_6, STATE_7, STATE_8, STATE_9, STATE_10
} program_states;

#define VAR_SET(x)	x = 1
#define VAR_RST(x)  x = 0

#define IRS_ON sei()

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )
void Timer_init(void);

void RTC_init(void);

static volatile uint8_t s_60 = 0;				// licznik do 60 sekund
static volatile uint8_t s_60_set = 0;			// wlaczenie licznika do 60 sekund
static volatile uint8_t s_60_finished = 0;		// flaga skonczenia pracy licznika do 60 sekund

static volatile uint8_t led_red_pulsating_1s = 0;   // wlaczenie pulsowania diody czerwonej 1s
static volatile uint8_t led_green_pulsating_1s = 0; // jw dla zielonej

static volatile uint32_t box_seconds = 0;      // czas zamkni�cia pudelka w sekundach

ISR(RTC_CNT_vect)
{
	if (box_seconds) box_seconds--;
	if (led_green_pulsating_1s) LED_GREEN_PORT.OUTTGL = LED_GREEN_PIN;
	if (led_red_pulsating_1s)   LED_RED_PORT.OUTTGL = LED_RED_PIN;
	
	if (s_60_set == 1) s_60++;
	if (s_60 == 60) {
		s_60 = s_60_set = 0;
		s_60_finished = 1;
	}
	
	RTC.INTFLAGS = 0x01;
}

ISR(TCA0_OVF_vect)
{
	readEncoder();
	readButton();
	
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	LED_RED_PORT.DIRSET = LED_RED_PIN;
	LED_GREEN_PORT.DIRSET = LED_GREEN_PIN;
	BOX_PORT.DIRSET = BOX_PIN;
	
	SH_init();
	Encoder_init();
	Timer_init();
	RTC_init();
	IRS_ON;
	
	int8_t enc; //zmienna przechowuj�ca ruch enkodera
	uint8_t sw; // zmienna przechowuj�ca stan przycisku
	
	uint8_t first_on = 1; // zmienna przechowuj�ca informacj� o pierwszym uruchomieniu lub uruchomieniu po roz�adowaniu baterii urz�dzenia
	uint8_t display_time_flag = 0; // format czasu na wyswietlacuz
	uint8_t display_time_set  = 0;
	
	uint8_t box_state = DEVICE_L; // zmienna przechowujaca informacje o aktualnym stanie urzadzenia (zablokowane, odblokowane ale mechanicznie zablokowane)
	uint8_t battery_state = BATTERY_LOW; // zmienna przechowujaca informacje o stanie naladowania baterii
	
	box_time time_var = {0, 0, 0, 0};
	program_states state = START;
	
	box_seconds = 2000;
	while (1) {
		sw = returnButton();
		enc = returnEncoderValue();
		
		BOX_displayState(box_state);

		time_var.days = (box_seconds / 86400) % 365;
		time_var.hours = (box_seconds / 3600) % 24;
		time_var.minutes = (box_seconds / 60) % 60;
		time_var.seconds = box_seconds % 60;
		
		switch (state) {
			case START:
				if (first_on == 1) {
					first_on = 0;
					BOX_displayAnimation();
				}
				else if (box_state == DEVICE_L) {
					if ((sw != 0) || (enc != 0)) state = STATE_0;
				}
				else if (box_state == DEVICE_ULL) {
					if (sw != 0)
				}
			break;
			
			case STATE_0:
				LED_RED_PORT.OUTSET = LED_RED_PIN;
				if (box_seconds) box_state = DEVICE_ULL;
				else box_state = DEVICE_UL;
				if (s_60_finished == 1) {
					s_60_finished = 0;
					s_60_set = 1;
					state = STATE_1;
				}
				else state = STATE_2;
			break;
			
			case STATE_1:
				SH_clearXY(0, SH_DEVICE_STATE_HEIGHT, SH_WIDTH, SH_HEIGHT - SH_DEVICE_STATE_HEIGHT);
				SH_drawString(0, SH_HEIGHT/2 - 16, "Niski stan baterii", 15);
				SH_update();
				for (uint8_t i = 0; i < 4; i++) {
					LED_RED_PORT.OUTTGL = LED_RED_PIN;
					_delay_ms(200);
				}
				state = STATE_2;
			break;
			
			case STATE_2:
				SH_clearXY(0, SH_DEVICE_STATE_HEIGHT, SH_WIDTH, SH_HEIGHT - SH_DEVICE_STATE_HEIGHT);
				SH_drawString(0, SH_HEIGHT/2 - 16, "TekstA", 15);
				SH_update();
				VAR_SET(led_red_pulsating_1s);
				state = STATE_3;
			break;
			
			case STATE_3:
				VAR_SET(display_time_set);
				VAR_RST(led_red_pulsating_1s);
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				state = START;
			break;
		}
		
		if (display_time_set) BOX_displayTime(&time_var, box_state);
	}
}


void Timer_init(void)
{
	TCB0.CCMPL = 250;
	TCB0.CCMPH = 0;
	TCB0.CTRLB = TCB_CCMPEN_bm | TCB_CNTMODE0_bm | TCB_CNTMODE1_bm | TCB_CNTMODE2_bm;
	TCB0.CTRLA = TCB_ENABLE_bm;
	
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
}

void RTC_init(void)
{
	CLKCTRL.OSC32KCTRLA = 0b10000000;
	RTC.CLKSEL = 0x00;
	RTC.PER = 1;
	RTC.INTCTRL = 0x01;
	RTC.CTRLA = 0xF1;
}