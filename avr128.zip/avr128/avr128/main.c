/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )
void Timer_init(void);

ISR(TCA0_OVF_vect)
{
	readEncoder();
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	
	Timer_init();
	SPI_init();
	SH_init();
	Encoder_init();
	
	int8_t i = 0;
	uint8_t ct = 0;
	while (1) {
		i += returnEncoderValue();
		if (i > 9) i = 9;
		if (i < 0) i = 0;
		SH_clear();
		SH_drawChar(0, 0, i + '0', 15);
		SH_update();
	}
}


void Timer_init(void)
{
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
	sei();
}
