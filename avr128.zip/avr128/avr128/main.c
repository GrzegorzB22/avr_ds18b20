/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"
#include <string.h>
#include "device.h"
#include "pin_defines.h"

#define DEVICE_L_STAGE    0
#define DEVICE_UL_STAGE   1
#define DEVICE_UM_STAGE   2
#define DEVICE_OPEN_STAGE 3
#define DEVICE_CLOS_STAGE 4
#define DEVICE_FIN_STAGE  5

#define ENC_POSITIVE 1
#define ENC_NEGATIVE 0

#define DAYS_RATE 86400
#define HRS_RATE  3600
#define MIN_RATE  60

#define VAR_SET(x)	x = 1
#define VAR_RST(x)  x = 0

#define IRS_ON sei()

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )

void Timer_init(void);
void RTC_init(void);
void device_openProcess(void);

static volatile int32_t device_seconds = 0;
static volatile uint8_t device_count = 0;

static volatile uint8_t timer_60s = 60;
static volatile uint16_t timer_20m = 1200;

static volatile uint8_t led_red_puls = 0;
static volatile uint8_t led_green_puls_1s = 0;

static volatile uint8_t lock_timer = 7;

static volatile uint8_t tekstb_timer = 3;

static volatile uint8_t device_um_timer = 2;

static volatile uint8_t no_action_timer = 5;

static volatile uint16_t encoder_speed = 0;
ISR(RTC_CNT_vect)
{
	if (no_action_timer < 4) no_action_timer++;
	if (device_um_timer < 2) device_um_timer++;
	if (tekstb_timer < 3) tekstb_timer++;
	if (timer_20m < 1200) timer_20m++;
	if (lock_timer < 8) lock_timer++;
	if (led_green_puls_1s == 1) LED_GREEN_PORT.OUTTGL = LED_GREEN_PIN;
	if (device_count == 1) {
		if (device_seconds > 0) device_seconds--;
	}
	if (timer_60s < 60) timer_60s++;
	RTC.INTFLAGS = 0x01;
}

ISR(TCA0_OVF_vect)
{
	readEncoder();
	readButton();
	encoder_speed++;
	
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	LED_RED_PORT.DIRSET = LED_RED_PIN;
	LED_GREEN_PORT.DIRSET = LED_GREEN_PIN;
	DEVICE_PORT.DIRSET = DEVICE_PIN;
	
	SH_init();
	Encoder_init();
	Timer_init();
	RTC_init();
	IRS_ON;
	
	int enc; //zmienna przechowuj�ca ruch enkodera
	uint8_t sw; // zmienna przechowuj�ca stan przycisku
	
	uint8_t first_on = 1; // zmienna przechowuj�ca informacj� o pierwszym uruchomieniu lub uruchomieniu po roz�adowaniu baterii urz�dzenia
	uint8_t display_time_set  = 0;
	
	uint8_t device_state = DEVICE_L; // zmienna przechowujaca informacje o aktualnym stanie urzadzenia (zablokowane, odblokowane ale mechanicznie zablokowane)
	uint8_t battery_state = BATTERY_NLOW; // zmienna przechowujaca informacje o stanie naladowania baterii
	
	device_time time_var = {0, 0, 0, 0};
	
	uint8_t last_device_seconds = 0;
	uint8_t device_finished = 0; 
	
	uint8_t device_open_flag = 0;
	uint8_t device_close_flag = 0;

	uint8_t last_state = 0xFF;
	uint32_t last_seconds = 0xFF;
	
	uint8_t enc_direction = ENC_POSITIVE;
	
	uint8_t stages[6] = {0};
	//device_seconds = 8000000;
	while (1) {
		
		sw = returnButton();
		enc = returnEncoderValue();
		
		
		if (device_state != last_state) device_displayState(device_state);
		last_state = device_state;
		
		time_var.days = (device_seconds / 86400) % 365;
		time_var.hours = (device_seconds / 3600) % 24;
		time_var.minutes = (device_seconds / 60) % 60;
		time_var.seconds = device_seconds % 60;
		

		if (display_time_set == 1) device_displayTime(&time_var, device_state);
	
		/*
		if (device_close_flag == 1) {
			display_time_set = 0;
			static uint8_t sw_counter = 0;
			if (states[DEVICE_CLOS_STATE] == 0) {
				VAR_SET(led_red_puls);
				lock_timer = 0;
				states[DEVICE_CLOS_STATE] = 1;
			}
			else if (states[DEVICE_CLOS_STATE] == 1) {
				if (lock_timer < 7) {
					if (sw) sw_counter++;
					if (sw_counter == 2) {
						lock_timer = 7;
						device_close_flag = 0;
						continue;
					}
				}
				else stage = 2;
			}
			else if (stage == 2) {
				LED_RED_PORT.OUTSET = LED_RED_PIN;
				//animacja klodki
				//jesli niski stan baterii, informacja o tym
				SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(20, SH_HEIGHT/2 - 16, "tekstC", 15, FONT_8x16);
				SH_update();
				stage = 3;
			}
			else if (stage == 3) {
				if (sw) {
					device_close_flag = 0;
					display_time_set = 1;
					device_count = 1;
				}
			}
			
			if (stage > 0) {
				if (lock_timer <= 7) {
					SH_clearXY(SH_WIDTH - 8, 0, SH_WIDTH, 16);
					SH_drawChar(SH_WIDTH - 8, 0, (7 - lock_timer) + '0', 15, FONT_8x16);
					SH_update();
				}
				else {
					SH_clearXY(SH_WIDTH - 8, 0, SH_WIDTH, 16);
					SH_update();
				}
			}
		}
		*/
		
		
		if (device_open_flag == 1) {
			
			if (stages[DEVICE_OPEN_STAGE] == 0) {
				display_time_set = 0;
				DEVICE_PORT.OUTSET = DEVICE_PIN;
				device_state = DEVICE_UL;
				lock_timer = 0;
				VAR_SET(led_green_puls_1s);
				if (timer_20m == 1200) {
					timer_20m = 0;
					tekstb_timer = 0;
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_drawString(20, SH_HEIGHT/2 - 16, "tekstB", 15, FONT_8x16);
					SH_update();
				}
				stages[DEVICE_OPEN_STAGE] = 1;
			}
			else if (stages[DEVICE_OPEN_STAGE] == 1) {
				if (tekstb_timer == 3) {
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_update();
					tekstb_timer = 4;
				}
				if (sw) {
					lock_timer = 8;
					SH_clearXY(0, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_update();
					device_seconds = 0;
					display_time_set = 1;
					stages[DEVICE_OPEN_STAGE] = 2;
				}
			}
			else if (stages[DEVICE_OPEN_STAGE] == 2) {
				if (lock_timer < 7) VAR_SET(led_green_puls_1s);
				else if (lock_timer == 7) LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				stages[DEVICE_OPEN_STAGE] = 100;
			}
			if (stages[DEVICE_OPEN_STAGE] > 0) {
				if (lock_timer <= 7) {
					SH_clearXY(SH_WIDTH - 8, 0, SH_WIDTH, 16);
					SH_drawChar(SH_WIDTH - 8, 0, (7 - lock_timer) + '0', 15, FONT_8x16);
					SH_update();
				}
				else {
					SH_clearXY(SH_WIDTH - 8, 0, SH_WIDTH, 16);
					SH_update();
				}
			}
		}
		
		
		if ((device_count == 1) && (device_seconds == 0)) device_finished = 1;
		
		if (device_finished == 1) {
			if (stages[DEVICE_FIN_STAGE] == 0) {
				display_time_set = 0;
				device_count = last_device_seconds = 0;
				for (uint8_t i = 0; i < 3; i++) {
					LED_GREEN_PORT.OUTTGL = LED_GREEN_PIN;
					_delay_ms(10);
				}
				// animacja klodki
				VAR_SET(led_green_puls_1s);
				SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(20, SH_HEIGHT/2 - 16, "Nacisnij, aby otworzyc", 15, FONT_8x16);
				SH_update();
				stages[DEVICE_FIN_STAGE] = 1;		
			}
			else if (stages[DEVICE_FIN_STAGE] == 1) {
				if (sw) {
					VAR_RST(led_green_puls_1s);
					stages[DEVICE_FIN_STAGE] = 2;
					device_open_flag = 1;
				}
			}
		}
		
		
		if (device_state == DEVICE_L) {
			
			if (stages[DEVICE_L_STAGE] == 0) {
				if (sw || enc) {
					stages[DEVICE_L_STAGE] = 1;
					LED_RED_PORT.OUTSET = LED_RED_PIN;
					LED_GREEN_PORT.OUTCLR = LED_GREEN_PIN;
					
					if ((battery_state == BATTERY_LOW) && (timer_60s == 60)) {
						timer_60s = 0;
						SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
						SH_drawString(20, SH_HEIGHT/2 - 16, "Niski stan baterii", 15, FONT_8x16);
						SH_update();
						for (uint8_t i = 0; i < 3; i++) {
							LED_RED_PORT.OUTTGL = LED_RED_PIN;
							_delay_ms(200);
						}
						LED_RED_PORT.OUTSET = LED_RED_PIN;
					}
					
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_drawString(20, SH_HEIGHT/2 - 16, "tekstA", 15, FONT_8x16);
					SH_update();
					// wlaczyc pulsowanie
				}
			}
			else if (stages[DEVICE_L_STAGE] == 1) {
				if (sw) {
					display_time_set = 1;
					LED_RED_PORT.OUTSET = LED_RED_PIN;
					device_seconds = 5;
					device_count = 1;
					stages[DEVICE_L_STAGE] = 2;
				}
			}
		}
		/*
		else if (device_state == DEVICE_UM) {
			static uint16_t enc_counter = 0;
			static uint8_t stage = 0;
		
			if (enc < 0) {
				enc = -enc;
				enc_direction = ENC_NEGATIVE;
			}
			
			enc_counter += enc;
			//if (enc) no_action_timer = 0;
			
			if (stage == 0) {
				if (sw) device_open_flag = 1;
				else if (enc_counter == 1) { 
					device_um_timer = 0;
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_drawString(20, SH_HEIGHT/2, "Nacisnij, aby otworzyc", 15, FONT_8x16);
					SH_update();
					VAR_SET(led_green_puls_1s);
					stage = 1;
				}
			}
			else if (stage == 1) {
				if (enc_counter > 3) {
					VAR_RST(led_green_puls_1s);
					LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
					display_time_set = 1;
					stage = 2;
					enc_counter = 0;
				}
				if (device_um_timer < 2) {
					if (sw) device_open_flag = 1;
				}
				else if (device_um_timer > 10){
					device_seconds = 0;
					display_time_set = 1;
					stage = 2;
					enc_counter = 0;
				}
			}
			else if (stage == 2) {
				
				if (encoder_speed >= 200) {
					encoder_speed = 0;
					
					if (enc_direction == ENC_POSITIVE) device_seconds += (enc_counter * enc_counter * enc_counter * enc_counter * 60);
					else device_seconds -= (enc_counter * enc_counter * enc_counter * 60);
					if (device_seconds < 0) device_seconds = 0;
					
					enc_counter = 0;
					enc_direction = ENC_POSITIVE;
				}
				
				if (device_seconds == 0) {
					LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
					LED_GREEN_PORT.OUTCLR = LED_RED_PIN;
					if (no_action_timer == 4) {
						SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
						SH_drawString(20, SH_HEIGHT/2, "Nacisnij, aby otworzyc", 15, FONT_8x16);
						SH_update();
						display_time_set = 0;
					}
					if (sw) {
						device_open_flag = 1;
						stage = 100;
					}
				}
				else {
					LED_GREEN_PORT.OUTCLR = LED_GREEN_PIN;
					LED_RED_PORT.OUTSET = LED_RED_PIN;
					DEVICE_PORT.OUTCLR = DEVICE_PIN;
					display_time_set = 1;
					if (sw) {
						stage = 100;
						device_close_flag = 1;
					}
				}
			}
			else if (stage == 3) {
				if (sw) device_open_flag = 1;
			}
		}
		*/
	}
}

void Timer_init(void)
{
	TCB0.CCMPL = 250;
	TCB0.CCMPH = 0;
	TCB0.CTRLB = TCB_CCMPEN_bm | TCB_CNTMODE0_bm | TCB_CNTMODE1_bm | TCB_CNTMODE2_bm;
	TCB0.CTRLA = TCB_ENABLE_bm;
	
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
}

void RTC_init(void)
{
	CLKCTRL.OSC32KCTRLA = 0b10000000;
	RTC.CLKSEL = 0x00;
	RTC.PER = 1;
	RTC.INTCTRL = 0x01;
	RTC.CTRLA = 0xF1;
}