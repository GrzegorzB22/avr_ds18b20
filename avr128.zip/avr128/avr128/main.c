/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"
#include <string.h>
#include "device.h"
#include "pin_defines.h"

#define DAYS_RATE 86400
#define HRS_RATE  3600
#define MIN_RATE  60

#define VAR_SET(x)	x = 1
#define VAR_RST(x)  x = 0

#define IRS_ON sei()

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )

void Timer_init(void);
void RTC_init(void);
void device_close(void);
void device_open(void);

static volatile uint8_t timer_battery_level = 60;
static volatile uint8_t device_ull_button_timer = 2;

static volatile uint8_t led_red_puls = 0;
static volatile uint8_t led_green_puls = 0;


ISR(RTC_CNT_vect)
{
	if (timer_battery_level < 60) timer_battery_level++;
	if (device_ull_button_timer) device_ull_button_timer++;
	
	RTC.INTFLAGS = 0x01;
}

ISR(TCA0_OVF_vect)
{
	readEncoder();
	readButton();
	
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	LED_RED_PORT.DIRSET = LED_RED_PIN;
	LED_GREEN_PORT.DIRSET = LED_GREEN_PIN;
	DEVICE_PORT.DIRSET = DEVICE_PIN;
	
	SH_init();
	Encoder_init();
	Timer_init();
	RTC_init();
	IRS_ON;
	
	int8_t enc; //zmienna przechowuj�ca ruch enkodera
	uint8_t sw; // zmienna przechowuj�ca stan przycisku
	int8_t last_enc = 0xFF;
	uint8_t last_sw = 0xFF;
	
	uint8_t first_on = 1; // zmienna przechowuj�ca informacj� o pierwszym uruchomieniu lub uruchomieniu po roz�adowaniu baterii urz�dzenia
	uint8_t display_time_flag = 0; // format czasu na wyswietlacuz
	uint8_t display_time_set  = 0;
	
	uint8_t device_state = DEVICE_ULL; // zmienna przechowujaca informacje o aktualnym stanie urzadzenia (zablokowane, odblokowane ale mechanicznie zablokowane)
	uint8_t battery_state = BATTERY_NLOW; // zmienna przechowujaca informacje o stanie naladowania baterii
	
	device_time time_var = {0, 0, 0, 0};
	uint8_t device_seconds = 0;
	
	while (1) {
		sw = returnButton();
		enc = returnEncoderValue();
		
		device_displayState(device_state);

		time_var.days = (device_seconds / 86400) % 365;
		time_var.hours = (device_seconds / 3600) % 24;
		time_var.minutes = (device_seconds / 60) % 60;
		time_var.seconds = device_seconds % 60;
		
		if (first_on == 1) {
			first_on = 0;
			device_displayAnimation();
		}
		
		if (device_state == DEVICE_L) {
			static uint8_t enc_counter = 0;
			static uint8_t sw_counter = 0;
			
			if (enc) enc_counter++;
			if (sw) sw_counter++;
			
			if ((sw_counter == 1) || (enc_counter == 1)) {
				LED_RED_PORT.OUTSET = LED_GREEN_PIN;
				if ((battery_state == BATTERY_LOW) && (timer_battery_level == 60)) {
					timer_battery_level = 0;
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_drawString(20, SH_HEIGHT/2 - 16, "Niski stan baterii", 15);
					SH_update();
					for (uint8_t i = 0; i < 3; i++) {
						LED_RED_PORT.OUTTGL = LED_RED_PIN;
						_delay_ms(200);
					}
				}
				
				SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(20, SH_HEIGHT/2 - 16, "tekstA", 15);
				SH_update();
				led_red_puls = 1;	
			}
			
			if (sw_counter > 1) {
				display_time_set = 1;
				led_red_puls = 0;
				LED_RED_PORT.OUTSET = LED_RED_PIN;	
			}
			
		}
		else if (device_state == DEVICE_ULL) {
			static uint8_t enc_counter = 0;
			
			if ((device_seconds == 0) && (enc_counter > 0) && (enc_counter < 3)) {
				// procedura otwarcia
			}
			
			if (sw) {
				if (enc_counter < 3) {
					// procedura otwarcia
				}
			}
			else if ((device_ull_button_timer == 2) && ((enc_counter > 0) && (enc_counter < 3)) {
				device_seconds = 0;
				VAR_RST(led_green_puls);
				VAR_SET(display_time_set);
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				enc_counter = 3;
			}
			
			if (enc) {
				enc_counter++;
				if (enc_counter == 1) {
					device_ull_button_timer = 0;
					SH_clearXY(20, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
					SH_drawString(20, SH_HEIGHT/2 - 16, "Nacisnij, aby otworzyc", 15);
					SH_update();
					VAR_SET(led_green_puls);
				}
				else if (enc_counter == 3) {
					device_seconds = 0;
					VAR_RST(led_green_puls);
					VAR_SET(display_time_set);
					LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				}
				else if (enc_counter > 3) {
					if (device_seconds == 0) {
						LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
					}
				}
			}
		}
	}
}

void Timer_init(void)
{
	TCB0.CCMPL = 250;
	TCB0.CCMPH = 0;
	TCB0.CTRLB = TCB_CCMPEN_bm | TCB_CNTMODE0_bm | TCB_CNTMODE1_bm | TCB_CNTMODE2_bm;
	TCB0.CTRLA = TCB_ENABLE_bm;
	
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
}

void RTC_init(void)
{
	CLKCTRL.OSC32KCTRLA = 0b10000000;
	RTC.CLKSEL = 0x00;
	RTC.PER = 1;
	RTC.INTCTRL = 0x01;
	RTC.CTRLA = 0xF1;
}

void device_open(void)
{
	DEVICE_PORT.OUTSET = DEVICE_PIN;
	
}