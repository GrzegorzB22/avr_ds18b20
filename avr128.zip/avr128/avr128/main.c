/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"
#include <string.h>
#include "box.h"
#include "pin_defines.h"

#define DAYS_RATE 86400
#define HRS_RATE  3600
#define MIN_RATE  60

typedef enum {
	START, STATE_0, STATE_1, STATE_2, STATE_3, STATE_4, STATE_5, STATE_6, STATE_7, STATE_8, STATE_9, STATE_10, STATE_11, STATE_12, STATE_13, STATE_14, STATE_15, STATE_16, STATE_17, STATE_18, STATE_19, STATE_20, STATE_21, STATE_22,
	STATE_23, STATE_24, STATE_25, STATE_26, STATE_27, STATE_28, STATE_29, STATE_30, STATE_31, STATE_32, STATE_33, STATE_34, STATE_35, STATE_36, STATE_37, STATE_38, STATE_39, STATE_40
} program_states;

#define VAR_SET(x)	x = 1
#define VAR_RST(x)  x = 0

#define IRS_ON sei()

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )
void Timer_init(void);

void RTC_init(void);

static volatile uint8_t state_17_timer = 0;

static volatile uint8_t state_8_timer = 0;

static volatile uint16_t timer_20m = 1;

static volatile uint8_t state_7_timer = 0;

static volatile uint8_t led_red_pulsating_1s = 0;   // wlaczenie pulsowania diody czerwonej 1s
static volatile uint8_t led_green_pulsating_1s = 0; // jw dla zielonej

static volatile uint32_t box_seconds = 0;      // czas zamkni�cia pudelka w sekundach
static volatile uint8_t box_start_counting = 0;

static volatile uint8_t state_22_timer = 0;

static volatile uint8_t lock_counter = 0;

ISR(RTC_CNT_vect)
{
	if (box_seconds && box_start_counting) box_seconds--;
	if (state_7_timer) state_7_timer--;
	if (timer_20m) timer_20m--;
	if (state_8_timer) state_8_timer--;
	if (state_17_timer) state_17_timer--;
	if (state_22_timer) state_22_timer--;
	if (lock_counter) lock_counter--;
	if (led_green_pulsating_1s) LED_GREEN_PORT.OUTTGL = LED_GREEN_PIN;
	if (led_red_pulsating_1s)   LED_RED_PORT.OUTTGL = LED_RED_PIN;
	
	RTC.INTFLAGS = 0x01;
}

ISR(TCA0_OVF_vect)
{
	readEncoder();
	readButton();
	
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	LED_RED_PORT.DIRSET = LED_RED_PIN;
	LED_GREEN_PORT.DIRSET = LED_GREEN_PIN;
	BOX_PORT.DIRSET = BOX_PIN;
	
	SH_init();
	Encoder_init();
	Timer_init();
	RTC_init();
	IRS_ON;
	
	int8_t enc; //zmienna przechowuj�ca ruch enkodera
	uint8_t sw; // zmienna przechowuj�ca stan przycisku
	
	uint8_t first_on = 1; // zmienna przechowuj�ca informacj� o pierwszym uruchomieniu lub uruchomieniu po roz�adowaniu baterii urz�dzenia
	uint8_t display_time_flag = 0; // format czasu na wyswietlacuz
	uint8_t display_time_set  = 0;
	
	uint8_t box_state = DEVICE_ULL; // zmienna przechowujaca informacje o aktualnym stanie urzadzenia (zablokowane, odblokowane ale mechanicznie zablokowane)
	uint8_t battery_state = BATTERY_NLOW; // zmienna przechowujaca informacje o stanie naladowania baterii
	
	box_time time_var = {0, 0, 0, 0};
	program_states state = START;
	
	box_seconds = 2000;
	
	uint8_t enc_counter = 0;
	uint8_t update_timer_set = 0;
	uint8_t button_counter = 0;
	while (1) {
		SH_clearXY(SH_WIDTH - 16, SH_HEIGHT - 16, 16, 16);
		SH_drawChar(SH_WIDTH - 16, SH_HEIGHT - 16, (state / 10) + '0', 15);
		SH_drawChar(SH_WIDTH - 8, SH_HEIGHT - 16, (state % 10) + '0', 15);
		SH_update();
		sw = returnButton();
		enc = returnEncoderValue();
		
		if (box_state == DEVICE_UL) display_time_flag = DISPLAY_TIME_UL;
		else {
			if (time_var.days) display_time_flag = DISPLAY_TIME_UL;
			else display_time_flag = DISPLAY_TIME_L;
		}
		
		BOX_displayState(box_state);

		time_var.days = (box_seconds / 86400) % 365;
		time_var.hours = (box_seconds / 3600) % 24;
		time_var.minutes = (box_seconds / 60) % 60;
		time_var.seconds = box_seconds % 60;
		
		switch (state) {
			case START:
				if (first_on == 1) {
					BOX_displayAnimation();
					state = START;
					first_on = 0;
				}
				else {
					if (box_state == DEVICE_L) {
						if (sw || enc) state = STATE_0;
					}
					else if (box_state == DEVICE_ULL) {
						if (sw) state = STATE_6;
						else if (enc) state = STATE_15;
					}
				}
				break;
				
			case STATE_6:
				box_state = DEVICE_UL;
				BOX_PORT.OUTSET = BOX_PIN;
				state = STATE_7;
				break;
				
			case STATE_7:
				VAR_SET(led_green_pulsating_1s);
				state_7_timer = 7;
				if (timer_20m == 0) state = STATE_8;
				else {
					if (state_7_timer) {
						if (sw) state = STATE_10;
					}
					else state = STATE_14;
				}
				break;
				
			case STATE_8:
				state_8_timer = 3;
				timer_20m = 1200;
				state = STATE_9;
				break;
				
			case STATE_9:
				SH_clearXY(100, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(100, SH_HEIGHT/2 - 16, "tekstB", 15);
				SH_update();
				
				if (state_7_timer) {
					if (sw) state = STATE_10;
					else if (state_8_timer == 0) state = STATE_13;
				}
				else state = STATE_14;
				break;
				
			case STATE_10:
				VAR_SET(display_time_set);
				if (state_7_timer == 0) {
					if (box_seconds == 0) state = STATE_11;
				}
				else if (box_seconds) state = STATE_12;
				break;
				
			case STATE_11:
				VAR_RST(led_green_pulsating_1s);
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				break;
				
			case STATE_12:
				LED_GREEN_PORT.OUTCLR = LED_GREEN_PIN;
				LED_RED_PORT.OUTSET = LED_RED_PIN;
				break;
				
			case STATE_13:
				SH_clearXY(100, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_update();
				break;
				
			case STATE_14:
				BOX_PORT.OUTCLR = BOX_PIN;
				break;
				
			case STATE_15:
				enc_counter++;
				if (enc_counter < 3) state = STATE_16;
				else state = STATE_18;
				break;
				
			case STATE_16:
				SH_clearXY(40, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(40, SH_HEIGHT/2 - 16, "Nacisnij, aby otworzyc", 15);
				SH_update();
				VAR_SET(led_green_pulsating_1s);
				state = STATE_17;
				state_17_timer = 2;
				break;
				
			case STATE_17:
				if (state_17_timer == 0) state = STATE_19;
				else if (sw || (box_seconds == 0)) state = STATE_6;
				else if (enc) state = STATE_15;
				break;
				
			case STATE_18:
				VAR_SET(display_time_set);
				LED_RED_PORT.OUTCLR = LED_RED_PIN;
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				state = STATE_20;
				break;
				
			case STATE_19:
				box_seconds = 0;
				state = STATE_20;
				break;
				
			case STATE_20:
				update_timer_set = 1;
				if (box_seconds == 0) state = STATE_21;
				else state = STATE_24;
				break;
				
			case STATE_21:
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				state = STATE_22;
				state_22_timer = 4;
				break;
			
			case STATE_22:
				if (sw) state = STATE_6;
				else if (state_22_timer) state = STATE_23;
				break;
				
			case STATE_23:
				SH_clearXY(100, SH_HEIGHT/2 - 16, SH_WIDTH, SH_HEIGHT);
				SH_drawString(100, SH_HEIGHT/2 - 16, "Nacisnij, aby otworzyc", 15);
				SH_update();
				if (sw) state = STATE_6;
				break;
				
			case STATE_24:
				BOX_PORT.OUTCLR = BOX_PIN;
				LED_GREEN_PORT.OUTCLR = LED_GREEN_PIN;
				LED_RED_PORT.OUTSET = LED_RED_PIN;
				if (sw) state = STATE_25;
				break;
				
			case STATE_25:
				VAR_RST(update_timer_set);
				VAR_SET(led_red_pulsating_1s);
				state = STATE_26;
				break;
				
			case STATE_26:
				lock_counter = 7;
				state = STATE_27;
				break;
				
			case STATE_27:
				if (lock_counter == 0) state = STATE_30;
				else if (sw) state = STATE_28;
				break;
				
			case STATE_28:
				button_counter++;
				if (button_counter == 2) state = STATE_29;
				else state = STATE_27;
				break;
				
			case STATE_29:
				LED_GREEN_PORT.OUTSET = LED_GREEN_PIN;
				state = STATE_20;
				break;
				
			case STATE_30:
				if (sw) state = STATE_33;
				break;
				
			case STATE_33:
				VAR_SET(box_start_counting);
				VAR_SET(display_time_set);
				break;
				
		}
		
		if (update_timer_set) {
			if ((box_seconds != 0) && (enc != -1)) box_seconds += enc;
		}
		if (state_7_timer) BOX_displayLockTimer(state_7_timer);
		if (lock_counter) BOX_displayLockTimer(lock_counter);
		if (display_time_set) BOX_displayTime(&time_var, display_time_flag);
	}
}


void Timer_init(void)
{
	TCB0.CCMPL = 250;
	TCB0.CCMPH = 0;
	TCB0.CTRLB = TCB_CCMPEN_bm | TCB_CNTMODE0_bm | TCB_CNTMODE1_bm | TCB_CNTMODE2_bm;
	TCB0.CTRLA = TCB_ENABLE_bm;
	
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
}

void RTC_init(void)
{
	CLKCTRL.OSC32KCTRLA = 0b10000000;
	RTC.CLKSEL = 0x00;
	RTC.PER = 1;
	RTC.INTCTRL = 0x01;
	RTC.CTRLA = 0xF1;
}