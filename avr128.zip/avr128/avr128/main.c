/*
 * avr128.c
 *
 * Created: 05.11.2024 08:03:55
 * Author : re-gb
 */ 

#include <avr/io.h>
#include "spi.h"
#include "sh1122.h"
#include <util/delay.h>
#include <avr/interrupt.h>
#include "encoder.h"
#include <string.h>
#include "box.h"

static typedef enum = {
	START, STATE_0, STATE_1, STATE_2, STATE_3, STATE_4, STATE_5, STATE_6, STATE_7, STATE_8,
	STATE_9, STATE_10, STATE_11, STATE_12, STATE_13, STATE_14, STATE_15, STATE_16, STATE_17,
	STATE_18, STATE_19, STATE_20, STATE_21, STATE_22, STATE_23, STATE_24, STATE_25, STATE_26,
	STATE_27, STATE_28, STATE_29, STATE_30
} box_states;

#define DAYS_RATE 86400
#define HRS_RATE  3600
#define MIN_RATE  60

#define RTC_SET_INTERRUPT RTC.INTCTRL = 0x01
#define RTC_ON            RTC.CTRLA |= 0x01

#define RTC_RST_INTERRUPT RTC_INTCTRL = 0
#define RTC_OFF           RTC.CTRLA &= ~0x01

#define CPU_CLOCK_16MHz_set _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00011100 ) // zegar ustawiony na 16MHz, wszystkie ustawianie rejestrow AVR musza byc w _PROTECTED_WRITE()!
#define CPU_CLOCK_8MHz_set  _PROTECTED_WRITE( CLKCTRL.OSCHFCTRLA, 0b00010100 )
void Timer_init(void);

void RTC_init(void);


static volatile uint16_t s_60 = 0;
static volatile uint8_t s_60set = 0;
static volatile uint8_t s_60state = 1;
static volatile uint8_t red_pwm_start = 0;

static volatile uint32_t seconds = 0;

ISR(RTC_CNT_vect)
{
	RTC.INTFLAGS = 0x01;
}

ISR(TCA0_OVF_vect)
{
	static int8_t pwm_delta = 10;
	static uint8_t pwm_counter = 0;
	
	if (red_pwm_start == 1) {
		pwm_counter++;
		if (pwm_counter == 10) {
			pwm_counter = 0;
			TCB0.CCMPH += pwm_delta;
			if ((TCB0.CCMPH == 0) || (TCB0.CCMPH == 250)) pwm_delta = -pwm_delta;
		}
	}
	
	if (s_60set == 1) s_60++;
	if (s_60 == 6000) {
		s_60 = s_60set = 0;
		s_60state = 1;
	}
	
	readEncoder();
	readButton();
	
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

int main(void)
{
	CPU_CLOCK_16MHz_set;
	
	SH_init();
	Encoder_init();
	Timer_init();
	RTC_init();
	
	uint8_t sw;
	int8_t enc;
	
	char napisy[][30] = {"Niski stan baterii", "TekstA"};
		
	uint8_t device_state = DEVICE_L;
	uint8_t stan_baterii = 0;
	
	int pwm_value = 0;
	
	uint16_t days;
	uint8_t hours, minutes;
	
	LED_RED_PORT.DIRSET = LED_RED_PIN;
	
	box_states state = START;
	uint8_t first_on = 0;
	while (1) {
		sw = returnButton();
		enc = returnEncoderValue();

		minutes = (seconds / 60) % 60;
		hours   = (seconds / 3600) % 24;
		days    = (seconds / 86400) % 365;
		
		switch (state) {
			START:
			if (first_on == 1) state = STATE_0;
			else
		}

	}
}


void Timer_init(void)
{
	TCB0.CCMPL = 250;
	TCB0.CCMPH = 0;
	TCB0.CTRLB = TCB_CCMPEN_bm | TCB_CNTMODE0_bm | TCB_CNTMODE1_bm | TCB_CNTMODE2_bm;
	TCB0.CTRLA = TCB_ENABLE_bm;
	
	TCA0.SINGLE.PER = 1000-1;
	TCA0.SINGLE.INTCTRL = 0x01;
	TCA0.SINGLE.CTRLA = 0b00001001;
	sei();
}

void RTC_init(void)
{
	CLKCTRL.OSC32KCTRLA = 0b10000000;
	RTC.CLKSEL = RTC_CLKSEL_OSC32K_gc;
	RTC.PER = 0; // overflow co 1 s (liczenie od 0)
	RTC.CTRLA = 0b11111000;
	RTC_RST_INTERRUPT;
	RTC_OFF;
}