/*
 * spi.h
 *
 * Created: 05.11.2024 11:10:14
 *  Author: re-gb
 */ 


#ifndef SPI_H_
#define SPI_H_

#include <avr/io.h>
#include "pin_defines.h"

#define SPI_START SPI_CS_PORT.OUT &= ~SPI_CS_PIN
#define SPI_STOP  SPI_CS_PORT.OUT |= SPI_CS_PIN

void SPI_init(void);
void SPI_transmit(uint8_t data);

#endif /* SPI_H_ */